package it.example.meteo

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.tasks.await

object LocationHelper {
    private const val PREFS = "loc"

    // Roma come posizione di ripiego
    @SuppressLint("MissingPermission")
    suspend fun get(ctx: Context): Pair<Double, Double> {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            try {
                val loc = LocationServices.getFusedLocationProviderClient(ctx)
                    .getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                    .await()
                if (loc != null) {
                    prefs.edit()
                        .putFloat("lat", loc.latitude.toFloat())
                        .putFloat("lon", loc.longitude.toFloat())
                        .apply()
                    return loc.latitude to loc.longitude
                }
            } catch (_: Exception) {
            }
        }
        return prefs.getFloat("lat", 41.9028f).toDouble() to prefs.getFloat("lon", 12.4964f).toDouble()
    }
}
