package it.example.meteo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.math.roundToInt

object WeatherRepository {
    private const val PREFS = "weather"
    private const val KEY = "json"

    suspend fun fetch(ctx: Context, lat: Double, lon: Double): Forecast = withContext(Dispatchers.IO) {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,is_day" +
                "&hourly=temperature_2m,precipitation_probability,weather_code,relative_humidity_2m" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min," +
                "precipitation_probability_max,sunrise,sunset" +
                "&timezone=auto&forecast_days=7"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        val text = try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
        val forecast = parse(text)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, text).apply()
        forecast
    }

    fun cached(ctx: Context): Forecast? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?.let { runCatching { parse(it) }.getOrNull() }

    private fun JSONArray.doubles() = List(length()) { optDouble(it) }
    private fun JSONArray.ints() = List(length()) { optInt(it) }
    private fun JSONArray.strings() = List(length()) { getString(it) }

    private fun parse(text: String): Forecast {
        val root = JSONObject(text)
        val cur = root.getJSONObject("current")
        val d = root.getJSONObject("daily")
        val h = root.getJSONObject("hourly")

        val dates = d.getJSONArray("time").strings()
        val codes = d.getJSONArray("weather_code").ints()
        val tMax = d.getJSONArray("temperature_2m_max").doubles()
        val tMin = d.getJSONArray("temperature_2m_min").doubles()
        val pop = d.getJSONArray("precipitation_probability_max").ints()
        val sunrise = d.getJSONArray("sunrise").strings()
        val sunset = d.getJSONArray("sunset").strings()

        val hTemp = h.getJSONArray("temperature_2m").doubles()
        val hPop = h.getJSONArray("precipitation_probability").ints()
        val hCode = h.getJSONArray("weather_code").ints()
        val hHum = h.getJSONArray("relative_humidity_2m").doubles()

        val days = dates.indices.map { i ->
            val from = i * 24
            val to = minOf(from + 24, hTemp.size)
            val hours = (from until to).map { idx ->
                Hour(LocalTime.of(idx - from, 0), hTemp[idx], hPop[idx], hCode[idx])
            }
            val hum = if (to > from) hHum.subList(from, to).average().roundToInt() else 0
            Day(
                date = LocalDate.parse(dates[i]),
                code = codes[i],
                tMax = tMax[i],
                tMin = tMin[i],
                pop = pop[i],
                humidity = hum,
                sunrise = LocalDateTime.parse(sunrise[i]).toLocalTime(),
                sunset = LocalDateTime.parse(sunset[i]).toLocalTime(),
                hours = hours
            )
        }
        return Forecast(
            currentTemp = cur.getDouble("temperature_2m"),
            currentCode = cur.getInt("weather_code"),
            isDay = cur.getInt("is_day") == 1,
            days = days
        )
    }
}
