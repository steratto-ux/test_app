package it.example.meteo

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

fun iconFor(code: Int, isDay: Boolean = true): Int = when (code) {
    0 -> if (isDay) R.drawable.ic_clear else R.drawable.ic_moon
    1, 2 -> R.drawable.ic_partly
    3 -> R.drawable.ic_cloudy
    45, 48 -> R.drawable.ic_fog
    in 51..67, in 80..82 -> R.drawable.ic_rain
    in 71..77, 85, 86 -> R.drawable.ic_snow
    95, 96, 99 -> R.drawable.ic_storm
    else -> R.drawable.ic_cloudy
}

fun conditionText(code: Int): String = when (code) {
    0 -> "Sereno"
    1, 2 -> "Poco nuvoloso"
    3 -> "Coperto"
    45, 48 -> "Nebbia"
    in 51..57 -> "Pioviggine"
    in 61..67 -> "Pioggia"
    in 71..77 -> "Neve"
    in 80..82 -> "Rovesci"
    85, 86 -> "Rovesci di neve"
    95, 96, 99 -> "Temporale"
    else -> "Variabile"
}

fun Double.deg(): String = "${roundToInt()}°"

private fun String.cap() = replaceFirstChar { it.uppercase() }

fun dayLabel(date: LocalDate): String {
    val today = LocalDate.now()
    return when (date) {
        today -> "Oggi"
        today.plusDays(1) -> "Domani"
        else -> date.format(DateTimeFormatter.ofPattern("EEEE d", Locale.ITALIAN)).cap()
    }
}

fun fullDate(date: LocalDate): String =
    date.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.ITALIAN)).cap()
