package it.example.meteo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class WeatherViewModel(app: Application) : AndroidViewModel(app) {
    var forecast by mutableStateOf<Forecast?>(WeatherRepository.cached(app))
        private set
    var refreshing by mutableStateOf(false)
        private set
    var error by mutableStateOf(false)
        private set
    var selected by mutableStateOf<Int?>(null)

    fun load() {
        viewModelScope.launch {
            refreshing = true
            try {
                val ctx = getApplication<Application>()
                val (lat, lon) = LocationHelper.get(ctx)
                forecast = WeatherRepository.fetch(ctx, lat, lon)
                error = false
                WeatherWidget().updateAll(ctx)
            } catch (e: Exception) {
                error = true
            } finally {
                refreshing = false
            }
        }
    }
}
