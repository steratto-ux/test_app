package it.example.meteo

import java.util.Locale

object MapHtml {
    fun build(lat: Double, lon: Double): String =
        TEMPLATE
            .replace("__LAT__", String.format(Locale.US, "%.4f", lat))
            .replace("__LON__", String.format(Locale.US, "%.4f", lon))

    private val TEMPLATE = """
<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<style>
html,body{height:100%;margin:0;background:#0F1318;font-family:sans-serif}
#map{position:absolute;top:0;left:0;right:0;bottom:0}
#panel{position:absolute;left:8px;right:8px;bottom:8px;z-index:1000;background:rgba(15,19,24,0.93);color:#F2F5F9;border-radius:16px;padding:12px 14px;font-size:13px}
#when{font-size:15px;font-weight:600}
#hr{width:100%;margin:10px 0}
.row{display:flex;justify-content:space-between;align-items:center}
label{display:flex;align-items:center;gap:6px;font-size:14px}
.legend{display:flex;align-items:center;gap:8px;margin-top:10px;font-size:12px;color:#8D98A6}
.bar{flex:1;height:10px;border-radius:5px;background:linear-gradient(90deg,#FFF176,#FFD600,#FFA000,#F4511E,#D50000)}
.note{margin-top:8px;font-size:11px;color:#8D98A6}
</style></head>
<body>
<div id="map"></div>
<div id="panel">
  <div class="row"><span id="when">Caricamento…</span></div>
  <input id="hr" type="range" min="0" max="12" value="0" step="1">
  <div class="row">
    <label><input type="checkbox" id="ck_c" checked> Nuvole</label>
    <label><input type="checkbox" id="ck_r" checked> Precipitazioni</label>
  </div>
  <div class="legend"><span>leggere</span><div class="bar"></div><span>intense</span></div>
  <div class="note">Previsione del modello meteo (griglia di circa 17 km), non radar. Mappa: OpenTopoMap / OpenStreetMap.</div>
</div>
<script>
var LAT=__LAT__, LON=__LON__;
var N=5, STEP=0.15;
var dLon=STEP/Math.cos(LAT*Math.PI/180);
var map=L.map('map',{minZoom:5,maxZoom:15}).setView([LAT,LON],8);
L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',{
  maxZoom:15,subdomains:'abc',
  attribution:'&copy; OpenStreetMap, SRTM | &copy; OpenTopoMap (CC-BY-SA)'
}).addTo(map);
var cloudLayer=L.layerGroup().addTo(map);
var rainLayer=L.layerGroup().addTo(map);
var marker=L.circleMarker([LAT,LON],{radius:7,color:'#ffffff',weight:3,fillColor:'#1E88E5',fillOpacity:1}).addTo(map);
var data=null, lats=[], lons=[];
var whenEl=document.getElementById('when');
var hr=document.getElementById('hr');

function rainColor(r){
  if(r<0.5) return '#FFF176';
  if(r<1) return '#FFD600';
  if(r<2.5) return '#FFA000';
  if(r<5) return '#F4511E';
  return '#D50000';
}

function render(h){
  cloudLayer.clearLayers();
  rainLayer.clearLayers();
  for(var k=0;k<data.length;k++){
    var p=data[k];
    if(!p||!p.hourly) continue;
    var b=[[lats[k]-STEP/2,lons[k]-dLon/2],[lats[k]+STEP/2,lons[k]+dLon/2]];
    var c=p.hourly.cloud_cover[h], r=p.hourly.precipitation[h];
    if(c!==null && c>10){
      L.rectangle(b,{stroke:false,fillColor:'#6B7B8C',fillOpacity:Math.min(0.5,c/100*0.5),interactive:false}).addTo(cloudLayer);
    }
    if(r!==null && r>=0.1){
      L.rectangle(b,{stroke:false,fillColor:rainColor(r),fillOpacity:0.7,interactive:false}).addTo(rainLayer);
    }
  }
  marker.bringToFront();
  var t=data[0].hourly.time[h];
  whenEl.textContent=t.substr(8,2)+'/'+t.substr(5,2)+' ore '+t.substr(11,5)+(h===0?' (adesso)':'');
}

function toggle(id,layer){
  document.getElementById(id).addEventListener('change',function(e){
    if(e.target.checked){map.addLayer(layer);marker.bringToFront();}else{map.removeLayer(layer);}
  });
}
toggle('ck_c',cloudLayer);
toggle('ck_r',rainLayer);

for(var i=-N;i<=N;i++){
  for(var j=-N;j<=N;j++){
    lats.push(LAT+i*STEP);
    lons.push(LON+j*dLon);
  }
}
var url='https://api.open-meteo.com/v1/forecast?latitude='+lats.map(function(v){return v.toFixed(3);}).join(',')+
  '&longitude='+lons.map(function(v){return v.toFixed(3);}).join(',')+
  '&hourly=precipitation,cloud_cover&forecast_hours=13&timezone=auto';

fetch(url).then(function(r){
  if(!r.ok) throw new Error('HTTP '+r.status);
  return r.json();
}).then(function(j){
  data=Array.isArray(j)?j:[j];
  hr.max=data[0].hourly.time.length-1;
  hr.addEventListener('input',function(){render(parseInt(hr.value,10));});
  render(0);
}).catch(function(e){
  whenEl.textContent='Dati non disponibili ('+e.message+')';
});
</script>
</body></html>
"""
}
