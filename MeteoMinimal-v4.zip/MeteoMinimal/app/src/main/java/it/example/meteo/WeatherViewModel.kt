package it.example.meteo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class WeatherViewModel(app: Application) : AndroidViewModel(app) {
    var forecast by mutableStateOf<Forecast?>(WeatherRepository.cached(app))
        private set
    var refreshing by mutableStateOf(false)
        private set
    var error by mutableStateOf(false)
        private set
    var selected by mutableStateOf<Int?>(null)

    // null = posizione attuale (GPS)
    var place by mutableStateOf<Place?>(null)
        private set
    var favorites by mutableStateOf(PlaceStore.list(app))
        private set

    private var job: Job? = null

    fun load() {
        job?.cancel()
        job = viewModelScope.launch {
            refreshing = true
            try {
                val ctx = getApplication<Application>()
                val p = place
                if (p == null) {
                    val (lat, lon) = LocationHelper.get(ctx)
                    forecast = WeatherRepository.fetch(ctx, lat, lon)
                    WeatherWidget().updateAll(ctx)
                } else {
                    forecast = WeatherRepository.fetchPlace(p.lat, p.lon, p.name)
                }
                error = false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = true
            } finally {
                refreshing = false
            }
        }
    }

    fun selectPlace(p: Place?) {
        place = p
        selected = null
        error = false
        forecast = if (p == null) WeatherRepository.cached(getApplication<Application>()) else null
        load()
    }

    fun toggleFavorite(p: Place) {
        favorites = PlaceStore.toggle(getApplication<Application>(), p)
    }
}
