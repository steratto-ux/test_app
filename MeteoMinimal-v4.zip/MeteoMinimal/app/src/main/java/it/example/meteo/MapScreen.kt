package it.example.meteo

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.tan

private const val TILE_DP = 256.0
private const val MIN_ZOOM = 5.0
private const val MAX_ZOOM = 15.0
private const val GRID_N = 9          // griglia (2N+1) x (2N+1) = 19 x 19 punti
private const val GRID_STEP = 0.07    // gradi (circa 8 km)
private const val UPSCALE = 8         // infittimento della griglia per l'aspetto morbido
private const val CACHE_MS = 10 * 60 * 1000L

private data class TileRef(val z: Int, val x: Int, val y: Int)

private class MapData(
    val times: List<String>,
    val g: Int,
    val south: Double,
    val north: Double,
    val west: Double,
    val east: Double,
    val precip: Array<DoubleArray>,
    val cloud: Array<DoubleArray>
)

private var cachedMap: Triple<String, Long, MapData>? = null

private fun worldX(lon: Double): Double = (lon + 180.0) / 360.0

private fun worldY(lat: Double): Double {
    val r = Math.toRadians(lat.coerceIn(-85.0, 85.0))
    return (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0
}

// ---------- rendering morbido -------------------------------------------------

private fun cubic(p0: Double, p1: Double, p2: Double, p3: Double, t: Double): Double =
    p1 + 0.5 * t * (p2 - p0 + t * (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3 + t * (3.0 * (p1 - p2) + p3 - p0)))

private fun lerpRgb(a: Int, b: Int, t: Double): Int {
    val ar = (a shr 16) and 0xFF
    val ag = (a shr 8) and 0xFF
    val ab = a and 0xFF
    val br = (b shr 16) and 0xFF
    val bg = (b shr 8) and 0xFF
    val bb = b and 0xFF
    val r = (ar + (br - ar) * t).roundToInt()
    val g = (ag + (bg - ag) * t).roundToInt()
    val bl = (ab + (bb - ab) * t).roundToInt()
    return (r shl 16) or (g shl 8) or bl
}

private val RAIN_STOPS = doubleArrayOf(0.05, 0.5, 1.5, 4.0, 8.0)
private val RAIN_COLORS = intArrayOf(0xFFF59D, 0xFFE000, 0xFFA000, 0xF4511E, 0xD50000)

// giallo = leggere, rosso = intense
private fun rainPixel(r: Double, fade: Double): Int {
    if (r < 0.05) return 0
    val idx = RAIN_STOPS.indexOfLast { r >= it }.coerceAtLeast(0)
    val rgb = if (idx >= RAIN_STOPS.size - 1) {
        RAIN_COLORS.last()
    } else {
        val t = ((r - RAIN_STOPS[idx]) / (RAIN_STOPS[idx + 1] - RAIN_STOPS[idx])).coerceIn(0.0, 1.0)
        lerpRgb(RAIN_COLORS[idx], RAIN_COLORS[idx + 1], t)
    }
    val alpha = (min(1.0, r / 0.4) * 0.8 * fade * 255).roundToInt().coerceIn(0, 255)
    return (alpha shl 24) or rgb
}

private fun cloudPixel(c: Double, fade: Double): Int {
    val a = ((c - 15.0) / 85.0).coerceIn(0.0, 1.0).pow(1.2)
    val alpha = (a * 0.55 * fade * 255).roundToInt().coerceIn(0, 255)
    return if (alpha == 0) 0 else (alpha shl 24) or 0x6B7B8C
}

private fun buildOverlay(values: DoubleArray, g: Int, rain: Boolean): ImageBitmap {
    val s = (g - 1) * UPSCALE + 1
    val px = IntArray(s * s)
    fun v(i: Int, j: Int): Double = values[i.coerceIn(0, g - 1) * g + j.coerceIn(0, g - 1)]
    val col = DoubleArray(4)
    for (r in 0 until s) {
        val fy = (g - 1) - r.toDouble() / (s - 1) * (g - 1)   // riga 0 = nord
        val iy = floor(fy).toInt().coerceIn(0, g - 2)
        val ty = fy - iy
        for (c in 0 until s) {
            val fx = c.toDouble() / (s - 1) * (g - 1)
            val ix = floor(fx).toInt().coerceIn(0, g - 2)
            val tx = fx - ix
            for (m in -1..2) {
                col[m + 1] = cubic(v(iy + m, ix - 1), v(iy + m, ix), v(iy + m, ix + 1), v(iy + m, ix + 2), tx)
            }
            val value = max(0.0, cubic(col[0], col[1], col[2], col[3], ty))
            // sfuma i bordi dell'area per non far vedere il rettangolo
            val edge = min(min(fx, (g - 1) - fx), min(fy, (g - 1) - fy))
            val u = (edge / 1.5).coerceIn(0.0, 1.0)
            val fade = u * u * (3.0 - 2.0 * u)
            px[r * s + c] = if (rain) rainPixel(value, fade) else cloudPixel(min(100.0, value), fade)
        }
    }
    val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
    bmp.setPixels(px, 0, s, 0, 0, s, s)
    return bmp.asImageBitmap()
}

// ---------- rete --------------------------------------------------------------

private fun downloadTile(z: Int, x: Int, y: Int): ImageBitmap? {
    val urls = listOf(
        "https://${"abc"[(x + y) % 3]}.tile.opentopomap.org/$z/$x/$y.png",
        "https://tile.openstreetmap.org/$z/$x/$y.png"
    )
    for (u in urls) {
        try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "MeteoMinimal/1.3 (app personale)")
            try {
                if (c.responseCode == 200) {
                    val bmp = BitmapFactory.decodeStream(c.inputStream)
                    if (bmp != null) return bmp.asImageBitmap()
                }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            // prova il server successivo
        }
    }
    return null
}

private fun fetchChunk(lats: List<Double>, lons: List<Double>): List<JSONObject> {
    val url = "https://api.open-meteo.com/v1/forecast?latitude=" +
        lats.joinToString(",") { "%.3f".format(Locale.US, it) } +
        "&longitude=" + lons.joinToString(",") { "%.3f".format(Locale.US, it) } +
        "&hourly=precipitation,cloud_cover&forecast_hours=13&timezone=auto"
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15000
    conn.readTimeout = 15000
    conn.setRequestProperty("User-Agent", "MeteoMinimal/1.3 (app personale)")
    val text = try {
        if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
        conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
    val arr = if (text.trimStart().startsWith("[")) JSONArray(text) else JSONArray().put(JSONObject(text))
    return List(arr.length()) { arr.getJSONObject(it) }
}

private suspend fun fetchMapData(lat: Double, lon: Double): MapData = coroutineScope {
    val stepLon = GRID_STEP / cos(Math.toRadians(lat))
    val g = 2 * GRID_N + 1
    val lats = ArrayList<Double>()
    val lons = ArrayList<Double>()
    for (i in -GRID_N..GRID_N) {
        for (j in -GRID_N..GRID_N) {
            lats.add(lat + i * GRID_STEP)
            lons.add(lon + j * stepLon)
        }
    }
    val objects = (0 until lats.size step 100).map { start ->
        val end = min(start + 100, lats.size)
        async(Dispatchers.IO) { fetchChunk(lats.subList(start, end), lons.subList(start, end)) }
    }.awaitAll().flatten()

    val tArr = objects[0].getJSONObject("hourly").getJSONArray("time")
    val times = List(tArr.length()) { tArr.getString(it) }
    val pArrs = objects.map { it.getJSONObject("hourly").getJSONArray("precipitation") }
    val cArrs = objects.map { it.getJSONObject("hourly").getJSONArray("cloud_cover") }
    val precip = Array(times.size) { h ->
        DoubleArray(objects.size) { k -> if (pArrs[k].isNull(h)) 0.0 else pArrs[k].getDouble(h) }
    }
    val cloud = Array(times.size) { h ->
        DoubleArray(objects.size) { k -> if (cArrs[k].isNull(h)) 0.0 else cArrs[k].getDouble(h) }
    }
    MapData(
        times = times,
        g = g,
        south = lat - GRID_N * GRID_STEP,
        north = lat + GRID_N * GRID_STEP,
        west = lon - GRID_N * stepLon,
        east = lon + GRID_N * stepLon,
        precip = precip,
        cloud = cloud
    )
}

private suspend fun loadMapData(lat: Double, lon: Double): MapData {
    val key = "%.2f,%.2f".format(Locale.US, lat, lon)
    val c = cachedMap
    if (c != null && c.first == key && System.currentTimeMillis() - c.second < CACHE_MS) return c.third
    val d = fetchMapData(lat, lon)
    cachedMap = Triple(key, System.currentTimeMillis(), d)
    return d
}

private fun mapTime(t: String, h: Int): String =
    t.substring(8, 10) + "/" + t.substring(5, 7) + " ore " + t.substring(11, 16) + (if (h == 0) " (adesso)" else "")

// ---------- interfaccia -------------------------------------------------------

@Composable
private fun ZoomButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xE60F1318)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(label, 22.sp) }
}

@Composable
fun MapScreen(lat: Double, lon: Double, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val dens = LocalDensity.current.density

    var wx by remember { mutableStateOf(worldX(lon)) }
    var wy by remember { mutableStateOf(worldY(lat)) }
    var zoom by remember { mutableStateOf(8.5) }
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    var data by remember { mutableStateOf<MapData?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var hour by remember { mutableStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var showClouds by remember { mutableStateOf(true) }
    var showRain by remember { mutableStateOf(true) }
    val tiles = remember { mutableStateMapOf<String, ImageBitmap>() }
    val loading = remember { HashSet<String>() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(lat, lon) {
        try {
            data = loadMapData(lat, lon)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "errore di rete"
        }
    }

    // Animazione delle ore
    LaunchedEffect(playing, data) {
        val md0 = data ?: return@LaunchedEffect
        while (playing) {
            delay(800)
            hour = (hour + 1) % md0.times.size
        }
    }

    val md = data
    val overlays: Pair<ImageBitmap?, ImageBitmap?> = remember(md, hour, showClouds, showRain) {
        if (md == null || hour !in md.times.indices) {
            Pair(null, null)
        } else {
            Pair(
                if (showClouds) buildOverlay(md.cloud[hour], md.g, false) else null,
                if (showRain) buildOverlay(md.precip[hour], md.g, true) else null
            )
        }
    }

    val w = viewSize.width.toFloat()
    val h = viewSize.height.toFloat()
    val tz = zoom.roundToInt().coerceIn(3, 15)
    val n = 1 shl tz
    val scalePx = TILE_DP * dens * 2.0.pow(zoom)
    val tilePx = TILE_DP * dens * 2.0.pow(zoom - tz)

    val visible: List<TileRef> = if (w <= 0f || h <= 0f) {
        emptyList()
    } else {
        val x0 = floor((wx - w / 2 / scalePx) * n).toInt()
        val x1 = floor((wx + w / 2 / scalePx) * n).toInt()
        val y0 = max(0, floor((wy - h / 2 / scalePx) * n).toInt())
        val y1 = min(n - 1, floor((wy + h / 2 / scalePx) * n).toInt())
        val list = ArrayList<TileRef>()
        for (ty in y0..y1) {
            for (tx in x0..x1) {
                if (list.size < 80) list.add(TileRef(tz, tx, ty))
            }
        }
        list
    }

    LaunchedEffect(visible) {
        if (tiles.size > 300) tiles.clear()
        for (t in visible) {
            val x = ((t.x % n) + n) % n
            val key = "${t.z}/$x/${t.y}"
            if (tiles.containsKey(key) || !loading.add(key)) continue
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { downloadTile(t.z, x, t.y) }
                if (bmp != null) tiles[key] = bmp
                loading.remove(key)
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            T(
                "←  Indietro", 16.sp, Accent,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(8.dp)
            )
            T("Nuvole e precipitazioni", 16.sp, weight = FontWeight.Medium, modifier = Modifier.padding(end = 8.dp))
        }

        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            Canvas(
                Modifier.fillMaxSize()
                    .background(Color(0xFF1A2029))
                    .onSizeChanged { viewSize = it }
                    .pointerInput(Unit) {
                        detectTransformGestures { centroid, pan, zoomChange, _ ->
                            val oldScale = TILE_DP * dens * 2.0.pow(zoom)
                            val newZoom = (zoom + ln(zoomChange.toDouble()) / ln(2.0)).coerceIn(MIN_ZOOM, MAX_ZOOM)
                            val newScale = TILE_DP * dens * 2.0.pow(newZoom)
                            val cw = size.width / 2.0
                            val ch = size.height / 2.0
                            val wxc = wx + (centroid.x - cw) / oldScale
                            val wyc = wy + (centroid.y - ch) / oldScale
                            wx = wxc - (centroid.x + pan.x - cw) / newScale
                            wy = wyc - (centroid.y + pan.y - ch) / newScale
                            zoom = newZoom
                        }
                    }
            ) {
                fun px(lonV: Double): Float = (w / 2 + (worldX(lonV) - wx) * scalePx).toFloat()
                fun py(latV: Double): Float = (h / 2 + (worldY(latV) - wy) * scalePx).toFloat()

                // Mappa topografica
                for (t in visible) {
                    val x = ((t.x % n) + n) % n
                    val img = tiles["${t.z}/$x/${t.y}"] ?: continue
                    val sx = w / 2 + (t.x.toDouble() / n - wx) * scalePx
                    val sy = h / 2 + (t.y.toDouble() / n - wy) * scalePx
                    val side = ceil(tilePx).toInt() + 1
                    drawImage(
                        img,
                        dstOffset = IntOffset(sx.roundToInt(), sy.roundToInt()),
                        dstSize = IntSize(side, side)
                    )
                }

                // Nuvole e precipitazioni (immagini morbide stese sull'area della griglia)
                val dd = data
                if (dd != null) {
                    val left = px(dd.west)
                    val right = px(dd.east)
                    val top = py(dd.north)
                    val bottom = py(dd.south)
                    val off = IntOffset(left.roundToInt(), top.roundToInt())
                    val sz = IntSize(max(1, (right - left).roundToInt()), max(1, (bottom - top).roundToInt()))
                    overlays.first?.let { drawImage(it, dstOffset = off, dstSize = sz) }
                    overlays.second?.let { drawImage(it, dstOffset = off, dstSize = sz) }
                }

                // Posizione della località
                val c = Offset(px(lon), py(lat))
                drawCircle(Color.White, 9.dp.toPx(), c)
                drawCircle(Color(0xFF1E88E5), 6.dp.toPx(), c)
            }

            if (tiles.isEmpty()) {
                T("Caricamento mappa…", 14.sp, Secondary, modifier = Modifier.align(Alignment.Center))
            }

            Column(
                Modifier.align(Alignment.TopEnd).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ZoomButton("+") { zoom = (zoom + 1).coerceAtMost(MAX_ZOOM) }
                ZoomButton("−") { zoom = (zoom - 1).coerceAtLeast(MIN_ZOOM) }
            }

            T(
                "© OpenStreetMap, SRTM · © OpenTopoMap", 10.sp, Secondary,
                modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA0F1318))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        Column(
            Modifier.fillMaxWidth().background(CardBg).navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            val label = when {
                md != null && hour in md.times.indices -> mapTime(md.times[hour], hour)
                error != null -> "Dati meteo non disponibili ($error)"
                else -> "Caricamento dati…"
            }
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                T(label, 15.sp, weight = FontWeight.SemiBold)
                if (md != null && md.times.size > 1) {
                    T(
                        if (playing) "■ Ferma" else "▶ Anima", 14.sp, Accent,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { playing = !playing }.padding(8.dp)
                    )
                }
            }
            if (md != null && md.times.size > 1) {
                Slider(
                    value = hour.toFloat(),
                    onValueChange = { hour = it.roundToInt() },
                    valueRange = 0f..(md.times.size - 1).toFloat(),
                    steps = md.times.size - 2
                )
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = showClouds, onCheckedChange = { showClouds = it })
                    T("Nuvole", 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = showRain, onCheckedChange = { showRain = it })
                    T("Precipitazioni", 14.sp)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                T("leggere", 12.sp, Secondary)
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFFFFF59D), Color(0xFFFFE000), Color(0xFFFFA000),
                                Color(0xFFF4511E), Color(0xFFD50000)
                            )
                        )
                    )
                )
                Spacer(Modifier.width(8.dp))
                T("intense", 12.sp, Secondary)
            }
            T(
                "Previsione del modello meteo, non radar. Zoom con due dita o con i pulsanti.",
                11.sp, Secondary, modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}
