package it.example.meteo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.roundToInt

object WeatherRepository {
    private const val PREFS = "weather"
    private const val KEY = "json"
    private const val BASE = "https://api.open-meteo.com/v1/forecast?"

    // Modello italiano ad alta risoluzione (ItaliaMeteo ARPAE ICON-2I, ~2 km, 3 giorni)
    // con ripiego automatico sul miglior modello disponibile per i giorni successivi.
    private val MODELS = listOf("italia_meteo_arpae_icon_2i", "best_match")

    private fun query(lat: Double, lon: Double, withModels: Boolean): String =
        "latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,weather_code,is_day" +
            "&hourly=temperature_2m,precipitation_probability,weather_code,relative_humidity_2m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min," +
            "precipitation_probability_max,sunrise,sunset" +
            "&timezone=auto&forecast_days=7" +
            (if (withModels) "&models=${MODELS.joinToString(",")}" else "")

    private fun httpGet(url: String, timeoutMs: Int = 12000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        conn.setRequestProperty("User-Agent", "MeteoMinimal/1.1 (app personale)")
        try {
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    suspend fun fetch(ctx: Context, lat: Double, lon: Double): Forecast = withContext(Dispatchers.IO) {
        val text = fetchText(lat, lon)

        val place = resolvePlace(ctx, lat, lon)
        val now = System.currentTimeMillis()
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, text)
            .putLong("ts", now)
            .apply()
        parse(text, place, now)
    }

    private fun fetchText(lat: Double, lon: Double): String =
        runCatching { httpGet(BASE + query(lat, lon, true)).also { parse(it, "", 0L) } }.getOrNull()
            ?: httpGet(BASE + query(lat, lon, false)).also { parse(it, "", 0L) }

    // Previsioni per una località scelta (non tocca i dati usati dal widget)
    suspend fun fetchPlace(lat: Double, lon: Double, name: String): Forecast = withContext(Dispatchers.IO) {
        parse(fetchText(lat, lon), name, System.currentTimeMillis())
    }

    fun cached(ctx: Context): Forecast? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val text = p.getString(KEY, null) ?: return null
        return runCatching {
            parse(text, p.getString("place", "Posizione attuale") ?: "Posizione attuale", p.getLong("ts", 0L))
        }.getOrNull()
    }

    // Nome della località tramite Nominatim (OpenStreetMap); richiesto di nuovo solo se ci si sposta.
    private fun resolvePlace(ctx: Context, lat: Double, lon: Double): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = p.getString("place", null)
        val lastLat = p.getFloat("pl_lat", 999f).toDouble()
        val lastLon = p.getFloat("pl_lon", 999f).toDouble()
        if (saved != null && abs(lat - lastLat) < 0.02 && abs(lon - lastLon) < 0.02) return saved
        return try {
            val url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12" +
                "&accept-language=it&lat=$lat&lon=$lon"
            val addr = JSONObject(httpGet(url, 8000)).getJSONObject("address")
            val name = listOf("city", "town", "village", "municipality", "hamlet", "suburb", "county")
                .firstNotNullOfOrNull { k -> addr.optString(k, "").takeIf { it.isNotBlank() } }
            if (name != null) {
                p.edit().putString("place", name)
                    .putFloat("pl_lat", lat.toFloat()).putFloat("pl_lon", lon.toFloat()).apply()
                name
            } else saved ?: "Posizione attuale"
        } catch (e: Exception) {
            saved ?: "Posizione attuale"
        }
    }

    private fun keys(name: String): List<String> = MODELS.map { "${name}_$it" } + name

    // Unisce le serie dei vari modelli: per ogni ora usa il primo valore disponibile.
    private fun JSONObject.nums(name: String, required: Boolean = true): List<Double?> {
        val sources = keys(name).mapNotNull { optJSONArray(it) }
        if (sources.isEmpty()) {
            if (required) throw JSONException("missing $name")
            return emptyList()
        }
        val n = sources.maxOf { it.length() }
        return List(n) { i ->
            sources.firstNotNullOfOrNull { a: JSONArray -> if (i < a.length() && !a.isNull(i)) a.getDouble(i) else null }
        }
    }

    private fun JSONObject.strs(name: String): List<String?> {
        val sources = keys(name).mapNotNull { optJSONArray(it) }
        if (sources.isEmpty()) throw JSONException("missing $name")
        val n = sources.maxOf { it.length() }
        return List(n) { i ->
            sources.firstNotNullOfOrNull { a: JSONArray -> if (i < a.length() && !a.isNull(i)) a.getString(i) else null }
        }
    }

    private fun JSONObject.scalar(name: String): Double? =
        keys(name).firstNotNullOfOrNull { k -> if (has(k) && !isNull(k)) getDouble(k) else null }

    private fun parse(text: String, place: String, ts: Long): Forecast {
        val root = JSONObject(text)
        val cur = root.getJSONObject("current")
        val d = root.getJSONObject("daily")
        val h = root.getJSONObject("hourly")

        val dateArr = d.getJSONArray("time")
        val dates = List(dateArr.length()) { dateArr.getString(it) }
        val codes = d.nums("weather_code")
        val tMax = d.nums("temperature_2m_max")
        val tMin = d.nums("temperature_2m_min")
        val pop = d.nums("precipitation_probability_max", false)
        val sunrise = d.strs("sunrise")
        val sunset = d.strs("sunset")

        val hTemp = h.nums("temperature_2m")
        val hPop = h.nums("precipitation_probability", false)
        val hCode = h.nums("weather_code")
        val hHum = h.nums("relative_humidity_2m", false)
        val anyTemp = hTemp.filterNotNull().firstOrNull() ?: 0.0

        val days = dates.indices.map { i ->
            val from = i * 24
            val to = minOf(from + 24, hTemp.size)
            val hours = (from until to).map { idx ->
                Hour(
                    LocalTime.of(idx - from, 0),
                    hTemp[idx] ?: anyTemp,
                    (hPop.getOrNull(idx) ?: 0.0).roundToInt(),
                    (hCode.getOrNull(idx) ?: 0.0).roundToInt()
                )
            }
            val hums = if (to > from) hHum.subList(minOf(from, hHum.size), minOf(to, hHum.size)).filterNotNull() else emptyList()
            Day(
                date = LocalDate.parse(dates[i]),
                code = (codes.getOrNull(i) ?: 0.0).roundToInt(),
                tMax = tMax.getOrNull(i) ?: hours.maxOfOrNull { it.temp } ?: anyTemp,
                tMin = tMin.getOrNull(i) ?: hours.minOfOrNull { it.temp } ?: anyTemp,
                pop = (pop.getOrNull(i) ?: hours.maxOfOrNull { it.pop }?.toDouble() ?: 0.0).roundToInt(),
                humidity = if (hums.isEmpty()) 0 else hums.average().roundToInt(),
                sunrise = sunrise.getOrNull(i)?.let { LocalDateTime.parse(it).toLocalTime() } ?: LocalTime.of(7, 0),
                sunset = sunset.getOrNull(i)?.let { LocalDateTime.parse(it).toLocalTime() } ?: LocalTime.of(18, 0),
                hours = hours
            )
        }
        return Forecast(
            currentTemp = cur.scalar("temperature_2m") ?: anyTemp,
            feelsLike = cur.scalar("apparent_temperature") ?: cur.scalar("temperature_2m") ?: anyTemp,
            currentCode = (cur.scalar("weather_code") ?: 0.0).roundToInt(),
            isDay = (cur.scalar("is_day") ?: 1.0) == 1.0,
            days = days,
            lat = root.optDouble("latitude", 41.9),
            lon = root.optDouble("longitude", 12.5),
            place = place,
            updatedAt = ts
        )
    }
}
