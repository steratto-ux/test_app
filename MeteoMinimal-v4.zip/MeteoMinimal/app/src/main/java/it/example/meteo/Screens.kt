package it.example.meteo

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime
import java.time.format.DateTimeFormatter

val Bg = Color(0xFF0F1318)
val CardBg = Color(0xFF1A2029)
val Primary = Color(0xFFF2F5F9)

private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")

@Composable
fun T(
    text: String,
    size: TextUnit = 14.sp,
    color: Color = Primary,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    align: TextAlign? = null
) = Text(text, fontSize = size, color = color, fontWeight = weight, modifier = modifier, textAlign = align)

@Composable
fun WeatherIcon(code: Int, isDay: Boolean, size: Dp) =
    Image(painterResource(iconFor(code, isDay)), contentDescription = conditionText(code), modifier = Modifier.size(size))

@Composable
fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        T(label, 12.sp, Secondary)
        Spacer(Modifier.height(2.dp))
        T(value, 15.sp, weight = FontWeight.Medium)
    }
}

@Composable
fun StatsRow(day: Day) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Stat("Pioggia", "${day.pop}%")
        Stat("Umidità", "${day.humidity}%")
        Stat("Alba", day.sunrise.format(timeFmt))
        Stat("Tramonto", day.sunset.format(timeFmt))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    forecast: Forecast?,
    error: Boolean,
    refreshing: Boolean,
    onRefresh: () -> Unit,
    onDay: (Int) -> Unit,
    onMap: () -> Unit,
    onSearch: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TopBar(forecast, onSearch, onMap)
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (forecast == null) {
                    item {
                        T(
                            if (error) "Impossibile caricare il meteo.\nTrascina verso il basso per riprovare." else "Caricamento…",
                            16.sp, Secondary, modifier = Modifier.fillMaxWidth().padding(48.dp), align = TextAlign.Center
                        )
                    }
                } else {
                    item { CurrentCard(forecast) }
                    item { FiveDayBox(forecast, onDay) }
                    item { T("Tutti i giorni", 16.sp, Secondary, modifier = Modifier.padding(start = 8.dp, top = 8.dp)) }
                    itemsIndexed(forecast.days) { i, d -> DayCard(d) { onDay(i) } }
                }
            }
        }
    }
}

@Composable
private fun TopBar(f: Forecast?, onSearch: () -> Unit, onMap: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable(onClick = onSearch)) {
            T(f?.place ?: "Meteo", 20.sp, weight = FontWeight.SemiBold)
            if (f != null) T(updatedText(f.updatedAt), 12.sp, Secondary)
        }
        IconButtonBox(R.drawable.ic_search, "Cerca una località", onSearch)
        if (f != null) {
            Spacer(Modifier.width(8.dp))
            IconButtonBox(R.drawable.ic_map, "Mappa nuvole e precipitazioni", onMap)
        }
    }
}

@Composable
private fun IconButtonBox(res: Int, description: String, onClick: () -> Unit) {
    Image(
        painterResource(res),
        contentDescription = description,
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .clickable(onClick = onClick)
            .padding(10.dp)
    )
}

@Composable
private fun DayCard(day: Day, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(CardBg)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            WeatherIcon(day.code, true, 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T(dayLabel(day.date), 18.sp, weight = FontWeight.SemiBold)
                T(conditionText(day.code), 14.sp, Secondary)
            }
            T(day.tMax.deg(), 28.sp, weight = FontWeight.SemiBold)
            Spacer(Modifier.width(8.dp))
            T(day.tMin.deg(), 20.sp, Secondary)
        }
        Spacer(Modifier.height(14.dp))
        StatsRow(day)
    }
}

@Composable
fun DetailScreen(day: Day, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .navigationBarsPadding().padding(16.dp)
    ) {
        T(
            "←  Indietro", 16.sp, Accent,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(8.dp)
        )
        Spacer(Modifier.height(8.dp))
        T(fullDate(day.date), 24.sp, weight = FontWeight.SemiBold)

        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            WeatherIcon(day.code, true, 88.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    T(day.tMax.deg(), 48.sp, weight = FontWeight.Light)
                    Spacer(Modifier.width(10.dp))
                    T(day.tMin.deg(), 26.sp, Secondary, modifier = Modifier.padding(bottom = 6.dp))
                }
                T(conditionText(day.code), 18.sp, Secondary)
            }
        }

        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardBg).padding(16.dp)) {
            StatsRow(day)
        }

        Spacer(Modifier.height(16.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardBg).padding(vertical = 16.dp)) {
            T("Temperatura oraria", 16.sp, weight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 16.dp))
            TemperatureChart(day.hours)
        }

        Spacer(Modifier.height(16.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardBg).padding(16.dp)) {
            T("Probabilità di precipitazioni", 16.sp, weight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            PrecipChart(day.hours)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("00", "06", "12", "18", "23").forEach { T(it, 11.sp, Secondary) }
            }
        }

        Spacer(Modifier.height(16.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardBg).padding(vertical = 16.dp)) {
            T("Ora per ora", 16.sp, weight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(8.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 8.dp)) {
                itemsIndexed(day.hours) { _, hr ->
                    val isDay = hr.time >= day.sunrise.withMinute(0) && hr.time < day.sunset.plusHours(1).withMinute(0).let {
                        if (day.sunset.hour == 23) LocalTime.MAX else it
                    }
                    Column(Modifier.width(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        T("%02d".format(hr.time.hour), 12.sp, Secondary)
                        Spacer(Modifier.height(6.dp))
                        WeatherIcon(hr.code, isDay, 28.dp)
                        Spacer(Modifier.height(6.dp))
                        T(hr.temp.deg(), 14.sp, weight = FontWeight.Medium)
                        T("${hr.pop}%", 11.sp, Accent)
                    }
                }
            }
        }
    }
}
