package it.example.meteo

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

val Accent: Color get() = if (Pal.dark) Color(0xFF6FB4FF) else Color(0xFF1E6FD0)
val Secondary: Color get() = if (Pal.dark) Color(0xFF8D98A6) else Color(0xFF5B6878)

@Composable
fun TemperatureChart(hours: List<Hour>, modifier: Modifier = Modifier) {
    val tm = rememberTextMeasurer()
    val valueStyle = TextStyle(color = Primary, fontSize = 12.sp)
    val axisStyle = TextStyle(color = Secondary, fontSize = 11.sp)
    Canvas(modifier.fillMaxWidth().height(200.dp)) {
        if (hours.size < 2) return@Canvas
        val padX = 18.dp.toPx()
        val top = 32.dp.toPx()
        val bottom = 28.dp.toPx()
        val w = size.width - 2 * padX
        val h = size.height - top - bottom
        val min = hours.minOf { it.temp }
        val max = hours.maxOf { it.temp }
        val range = (max - min).coerceAtLeast(1.0)
        fun x(i: Int) = padX + w * i / (hours.size - 1)
        fun y(t: Double) = top + h * (1 - ((t - min) / range)).toFloat()

        val line = Path().apply {
            moveTo(x(0), y(hours[0].temp))
            for (i in 1 until hours.size) {
                val mx = (x(i - 1) + x(i)) / 2
                cubicTo(mx, y(hours[i - 1].temp), mx, y(hours[i].temp), x(i), y(hours[i].temp))
            }
        }
        val fill = Path().apply {
            addPath(line)
            lineTo(x(hours.size - 1), size.height - bottom)
            lineTo(x(0), size.height - bottom)
            close()
        }
        drawPath(
            fill,
            Brush.verticalGradient(
                listOf(Accent.copy(alpha = 0.35f), Color.Transparent),
                startY = top, endY = size.height - bottom
            )
        )
        drawPath(line, Accent, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))

        for (i in hours.indices step 3) {
            val px = x(i)
            val py = y(hours[i].temp)
            drawCircle(CardBg, 5.dp.toPx(), Offset(px, py))
            drawCircle(Accent, 3.5.dp.toPx(), Offset(px, py))

            val t = tm.measure(hours[i].temp.deg(), valueStyle)
            drawText(t, topLeft = Offset(px - t.size.width / 2f, py - 24.dp.toPx()))

            val l = tm.measure("%02d".format(hours[i].time.hour), axisStyle)
            drawText(l, topLeft = Offset(px - l.size.width / 2f, size.height - bottom + 8.dp.toPx()))
        }
    }
}

@Composable
fun PrecipChart(hours: List<Hour>, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(64.dp)) {
        if (hours.isEmpty()) return@Canvas
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (hours.size - 1)) / hours.size
        hours.forEachIndexed { i, hr ->
            val bh = (size.height * hr.pop / 100f).coerceAtLeast(2.dp.toPx())
            drawRoundRect(
                color = Accent.copy(alpha = 0.25f + 0.75f * hr.pop / 100f),
                topLeft = Offset(i * (bw + gap), size.height - bh),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2)
            )
        }
    }
}
