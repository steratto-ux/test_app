package it.example.meteo

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun DailyTempChart(days: List<Day>, modifier: Modifier = Modifier) {
    val tm = rememberTextMeasurer()
    val hi = Color(0xFF4A9EF0)
    val lo = Color(0xFF8CC4F5)
    val maxStyle = TextStyle(color = Primary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    val minStyle = TextStyle(color = Secondary, fontSize = 13.sp)
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        val n = days.size
        if (n == 0) return@Canvas
        val top = 32.dp.toPx()
        val bottom = 32.dp.toPx()
        val h = size.height - top - bottom
        val minV = days.minOf { it.tMin }
        val maxV = days.maxOf { it.tMax }
        val range = (maxV - minV).coerceAtLeast(1.0)
        fun x(i: Int): Float = size.width * (i + 0.5f) / n
        fun y(v: Double): Float = top + h * (1f - ((v - minV) / range).toFloat())

        val maxs = days.map { it.tMax }
        val mins = days.map { it.tMin }

        fun curve(vals: List<Double>): Path = Path().apply {
            moveTo(x(0), y(vals[0]))
            for (i in 1 until vals.size) {
                val mx = (x(i - 1) + x(i)) / 2f
                cubicTo(mx, y(vals[i - 1]), mx, y(vals[i]), x(i), y(vals[i]))
            }
        }

        drawPath(curve(maxs), hi, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
        drawPath(curve(mins), lo, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))

        for (i in 0 until n) {
            drawCircle(hi, 4.5.dp.toPx(), Offset(x(i), y(maxs[i])))
            drawCircle(lo, 4.5.dp.toPx(), Offset(x(i), y(mins[i])))
            val a = tm.measure(maxs[i].deg(), maxStyle)
            drawText(a, topLeft = Offset(x(i) - a.size.width / 2f, y(maxs[i]) - 28.dp.toPx()))
            val b = tm.measure(mins[i].deg(), minStyle)
            drawText(b, topLeft = Offset(x(i) - b.size.width / 2f, y(mins[i]) + 8.dp.toPx()))
        }
    }
}
