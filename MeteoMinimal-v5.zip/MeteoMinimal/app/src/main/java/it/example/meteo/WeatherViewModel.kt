package it.example.meteo

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

private suspend fun <T> fetchOrNull(block: suspend () -> T?): T? =
    try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

class WeatherViewModel(app: Application) : AndroidViewModel(app) {
    var forecast by mutableStateOf<Forecast?>(WeatherRepository.cached(app))
        private set
    var refreshing by mutableStateOf(false)
        private set
    var error by mutableStateOf(false)
        private set
    var selected by mutableStateOf<Int?>(null)

    // null = posizione attuale (GPS)
    var place by mutableStateOf<Place?>(null)
        private set
    var favorites by mutableStateOf(PlaceStore.list(app))
        private set

    var nowcast by mutableStateOf<List<Double>?>(null)
        private set
    var air by mutableStateOf<AirQuality?>(null)
        private set

    private var job: Job? = null
    private var extraJob: Job? = null

    fun load() {
        job?.cancel()
        job = viewModelScope.launch {
            refreshing = true
            try {
                val ctx = getApplication<Application>()
                val p = place
                if (p == null) {
                    val (lat, lon) = LocationHelper.get(ctx)
                    forecast = WeatherRepository.fetch(ctx, lat, lon)
                    WeatherWidget().updateAll(ctx)
                } else {
                    forecast = WeatherRepository.fetchPlace(p.lat, p.lon, p.name)
                }
                error = false
                loadExtras()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = true
            } finally {
                refreshing = false
            }
        }
    }

    // Pioggia nelle prossime 2 ore e qualità dell'aria: arrivano dopo, senza bloccare il resto
    private fun loadExtras() {
        val fc = forecast ?: return
        extraJob?.cancel()
        extraJob = viewModelScope.launch {
            nowcast = fetchOrNull { NowcastRepository.fetch(fc.lat, fc.lon) }
            air = fetchOrNull { AirRepository.fetch(fc.lat, fc.lon) }
        }
    }

    fun selectPlace(p: Place?) {
        place = p
        selected = null
        error = false
        extraJob?.cancel()
        nowcast = null
        air = null
        forecast = if (p == null) WeatherRepository.cached(getApplication<Application>()) else null
        load()
    }

    fun toggleFavorite(p: Place) {
        favorites = PlaceStore.toggle(getApplication<Application>(), p)
    }
}
