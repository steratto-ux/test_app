package it.example.meteo

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Settings {
    private const val PREFS = "settings"

    var theme by mutableStateOf("dark")
        private set
    var tempUnit by mutableStateOf("C")
        private set
    var windUnit by mutableStateOf("kmh")
        private set
    var refreshMin by mutableStateOf(60)
        private set
    var rainAlerts by mutableStateOf(false)
        private set

    private var loaded = false

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        val p = prefs(ctx)
        theme = p.getString("theme", "dark") ?: "dark"
        tempUnit = p.getString("temp", "C") ?: "C"
        windUnit = p.getString("wind", "kmh") ?: "kmh"
        refreshMin = p.getInt("refresh", 60)
        rainAlerts = p.getBoolean("rain", false)
        loaded = true
    }

    fun setTheme(ctx: Context, v: String) {
        ensureLoaded(ctx)
        theme = v
        prefs(ctx).edit().putString("theme", v).apply()
    }

    fun setTempUnit(ctx: Context, v: String) {
        ensureLoaded(ctx)
        tempUnit = v
        prefs(ctx).edit().putString("temp", v).apply()
    }

    fun setWindUnit(ctx: Context, v: String) {
        ensureLoaded(ctx)
        windUnit = v
        prefs(ctx).edit().putString("wind", v).apply()
    }

    fun setRefreshMin(ctx: Context, v: Int) {
        ensureLoaded(ctx)
        refreshMin = v
        prefs(ctx).edit().putInt("refresh", v).apply()
    }

    fun setRainAlerts(ctx: Context, v: Boolean) {
        ensureLoaded(ctx)
        rainAlerts = v
        prefs(ctx).edit().putBoolean("rain", v).apply()
    }
}

object Pal {
    var systemDark by mutableStateOf(true)

    val dark: Boolean
        get() = when (Settings.theme) {
            "dark" -> true
            "light" -> false
            else -> systemDark
        }
}
