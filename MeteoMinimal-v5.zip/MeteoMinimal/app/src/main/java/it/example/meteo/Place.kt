package it.example.meteo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

data class Place(val name: String, val subtitle: String, val lat: Double, val lon: Double) {
    fun sameAs(o: Place): Boolean = abs(lat - o.lat) < 0.01 && abs(lon - o.lon) < 0.01
}

object PlaceStore {
    private const val PREFS = "places"
    private const val KEY = "favorites"

    fun list(ctx: Context): List<Place> {
        val text = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(text)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Place(o.getString("name"), o.optString("subtitle", ""), o.getDouble("lat"), o.getDouble("lon"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Aggiunge la località se non c'è, la toglie se è già tra i preferiti
    fun toggle(ctx: Context, p: Place): List<Place> {
        val cur = list(ctx).toMutableList()
        val i = cur.indexOfFirst { it.sameAs(p) }
        if (i >= 0) cur.removeAt(i) else cur.add(p)
        val arr = JSONArray()
        cur.forEach {
            arr.put(
                JSONObject().put("name", it.name).put("subtitle", it.subtitle)
                    .put("lat", it.lat).put("lon", it.lon)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
        return cur
    }
}

object GeoRepository {
    suspend fun search(query: String): List<Place> = withContext(Dispatchers.IO) {
        val url = "https://geocoding-api.open-meteo.com/v1/search?count=10&language=it&format=json&name=" +
            URLEncoder.encode(query, "UTF-8")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("User-Agent", "MeteoMinimal/1.3 (app personale)")
        val text = try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
        val arr = JSONObject(text).optJSONArray("results") ?: return@withContext emptyList<Place>()
        val out = ArrayList<Place>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sub = listOf("admin1", "country")
                .mapNotNull { k -> o.optString(k, "").takeIf { it.isNotBlank() } }
                .joinToString(", ")
            val p = Place(o.getString("name"), sub, o.getDouble("latitude"), o.getDouble("longitude"))
            if (out.none { it.sameAs(p) }) out.add(p)
        }
        out
    }
}
