package it.example.meteo

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

private fun httpText(url: String): String {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 10000
    conn.readTimeout = 10000
    conn.setRequestProperty("User-Agent", "MeteoMinimal/1.4 (app personale)")
    try {
        if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
        return conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
}

data class AirQuality(
    val aqi: Int?,
    val pm25: Double?,
    val pm10: Double?,
    val o3: Double?,
    val no2: Double?,
    val pollen: List<Pair<String, Double>>
)

object AirRepository {
    private val POLLEN = listOf(
        "alder_pollen" to "Ontano",
        "birch_pollen" to "Betulla",
        "grass_pollen" to "Graminacee",
        "mugwort_pollen" to "Artemisia",
        "olive_pollen" to "Olivo",
        "ragweed_pollen" to "Ambrosia"
    )

    suspend fun fetch(lat: Double, lon: Double): AirQuality? = withContext(Dispatchers.IO) {
        val base = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$lat&longitude=$lon&timezone=auto&current="
        val core = "european_aqi,pm10,pm2_5,ozone,nitrogen_dioxide"
        var cur: JSONObject? = null
        for (vars in listOf(core + "," + POLLEN.joinToString(",") { it.first }, core)) {
            try {
                cur = JSONObject(httpText(base + vars)).optJSONObject("current")
                if (cur != null) break
            } catch (e: Exception) {
                // riprova con meno variabili
            }
        }
        val c = cur ?: return@withContext null
        fun d(k: String): Double? = if (c.has(k) && !c.isNull(k)) c.getDouble(k) else null
        AirQuality(
            aqi = d("european_aqi")?.roundToInt(),
            pm25 = d("pm2_5"),
            pm10 = d("pm10"),
            o3 = d("ozone"),
            no2 = d("nitrogen_dioxide"),
            pollen = POLLEN.mapNotNull { (key, name) -> d(key)?.takeIf { it > 0.0 }?.let { name to it } }
        )
    }
}

// Precipitazioni (mm) ogni 15 minuti per le prossime 2 ore; il primo valore è l'intervallo in corso
object NowcastRepository {
    suspend fun fetch(lat: Double, lon: Double): List<Double>? = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&minutely_15=precipitation&forecast_minutely_15=8&timezone=auto"
        val arr = JSONObject(httpText(url)).optJSONObject("minutely_15")?.optJSONArray("precipitation")
            ?: return@withContext null
        List(arr.length()) { if (arr.isNull(it)) 0.0 else arr.getDouble(it) }
    }
}

fun nowcastSummary(mm: List<Double>): String {
    if (mm.isEmpty()) return ""
    fun wet(v: Double) = v >= 0.1
    return if (!wet(mm[0])) {
        val i = mm.indexOfFirst { wet(it) }
        if (i < 0) "Nessuna pioggia nelle prossime 2 ore" else "Pioggia in arrivo tra circa ${i * 15} minuti"
    } else {
        val i = mm.indexOfFirst { !wet(it) }
        if (i < 0) "Pioggia per le prossime 2 ore" else "Piove ora, smette tra circa ${i * 15} minuti"
    }
}
