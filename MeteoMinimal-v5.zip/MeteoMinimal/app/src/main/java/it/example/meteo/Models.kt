package it.example.meteo

import java.time.LocalDate
import java.time.LocalTime

data class Hour(val time: LocalTime, val temp: Double, val pop: Int, val code: Int)

data class Day(
    val date: LocalDate,
    val code: Int,
    val tMax: Double,
    val tMin: Double,
    val pop: Int,
    val humidity: Int,
    val sunrise: LocalTime,
    val sunset: LocalTime,
    val hours: List<Hour>,
    val windMax: Double = Double.NaN,
    val gustMax: Double = Double.NaN,
    val windDir: Double = Double.NaN,
    val uvMax: Double = Double.NaN,
    val pressure: Double = Double.NaN,
    val visKm: Double = Double.NaN,
    val dew: Double = Double.NaN
)

data class Forecast(
    val currentTemp: Double,
    val feelsLike: Double,
    val currentCode: Int,
    val isDay: Boolean,
    val days: List<Day>,
    val lat: Double,
    val lon: Double,
    val place: String,
    val updatedAt: Long,
    val windSpeed: Double = Double.NaN,
    val windGust: Double = Double.NaN,
    val windDir: Double = Double.NaN,
    val pressure: Double = Double.NaN,
    val visKm: Double = Double.NaN,
    val dew: Double = Double.NaN,
    val uv: Double = Double.NaN,
    val localTime: LocalTime = LocalTime.NOON
)
