package it.example.meteo

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.*
import java.util.concurrent.TimeUnit

class WeatherWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        Settings.ensureLoaded(applicationContext)
        val (lat, lon) = LocationHelper.get(applicationContext)
        WeatherRepository.fetch(applicationContext, lat, lon)
        WeatherWidget().updateAll(applicationContext)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        fun schedule(ctx: Context) {
            Settings.ensureLoaded(ctx)
            val minutes = Settings.refreshMin.coerceAtLeast(15).toLong()
            val req = PeriodicWorkRequestBuilder<WeatherWorker>(minutes, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                )
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("weather_refresh", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
