package it.example.meteo

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun CurrentCard(f: Forecast) {
    val today = f.days.firstOrNull()
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardBg)) {
        ConditionBackdrop(f.currentCode, f.isDay, Modifier.matchParentSize())
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            T(f.currentTemp.deg(), 88.sp, weight = FontWeight.Light)
            T(conditionText(f.currentCode), 20.sp)
            Spacer(Modifier.height(10.dp))
            T("Percepita ${f.feelsLike.deg()}", 16.sp, Secondary)
            if (today != null) {
                T("Min ${today.tMin.deg()}   ·   Max ${today.tMax.deg()}", 16.sp, Secondary)
            }
        }
    }
}

@Composable
fun ConditionBackdrop(code: Int, isDay: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "backdrop")
    val fast by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "fast"
    )
    val slow by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "slow"
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val s = w / 420f
        when (code) {
            0 -> if (isDay) sun(w, h) else night(w, h, slow)
            1, 2 -> {
                if (isDay) sun(w, h) else night(w, h, slow)
                cloud(w * 0.62f, h * 0.3f, s * 1.3f, Color(0x55B8C4D2))
            }
            45, 48 -> fog(w, h, slow)
            in 51..67, in 80..82 -> {
                clouds(w, h, s)
                rain(w, h, fast, 32)
            }
            in 71..77, 85, 86 -> {
                clouds(w, h, s)
                snow(w, h, slow, 26)
            }
            95, 96, 99 -> {
                clouds(w, h, s)
                rain(w, h, fast, 32)
                bolt(w, h)
            }
            else -> clouds(w, h, s)
        }
    }
}

private fun DrawScope.sun(w: Float, h: Float) {
    val c = Offset(w * 0.82f, h * 0.22f)
    drawCircle(
        brush = Brush.radialGradient(listOf(Color(0x66FFC93C), Color.Transparent), center = c, radius = h * 0.9f),
        radius = h * 0.9f,
        center = c
    )
    drawCircle(Color(0x55FFC93C), h * 0.12f, c)
}

private fun DrawScope.night(w: Float, h: Float, t: Float) {
    val c = Offset(w * 0.82f, h * 0.22f)
    drawCircle(
        brush = Brush.radialGradient(listOf(Color(0x558FB4FF), Color.Transparent), center = c, radius = h * 0.8f),
        radius = h * 0.8f,
        center = c
    )
    drawCircle(Color(0x66F5E6A8), h * 0.1f, c)
    for (i in 0 until 14) {
        val x = ((i * 47) % 100) / 100f * w
        val y = ((i * 29) % 60) / 100f * h
        val a = 0.3f + 0.4f * abs(sin((t * 2 * PI + i).toFloat()))
        drawCircle(Color.White.copy(alpha = a), 1.5.dp.toPx(), Offset(x, y))
    }
}

private fun DrawScope.cloud(cx: Float, cy: Float, s: Float, color: Color) {
    drawCircle(color, 26f * s, Offset(cx - 34f * s, cy))
    drawCircle(color, 34f * s, Offset(cx, cy - 14f * s))
    drawCircle(color, 26f * s, Offset(cx + 36f * s, cy))
    drawRoundRect(color, Offset(cx - 60f * s, cy - 2f * s), Size(124f * s, 28f * s), CornerRadius(14f * s))
}

private fun DrawScope.clouds(w: Float, h: Float, s: Float) {
    val col = Color(0x33B8C4D2)
    cloud(w * 0.25f, h * 0.2f, s * 1.2f, col)
    cloud(w * 0.7f, h * 0.15f, s * 1.5f, col)
    cloud(w * 0.5f, h * 0.35f, s * 1.0f, col)
}

private fun DrawScope.rain(w: Float, h: Float, t: Float, count: Int) {
    val len = 16.dp.toPx()
    for (i in 0 until count) {
        val x = ((i * 37) % 100) / 100f * w
        val phase = ((i * 53) % 100) / 100f
        val y = ((t + phase) % 1f) * (h + len) - len
        drawLine(
            Color(0x996FB4FF), Offset(x, y), Offset(x - len * 0.35f, y + len),
            strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.snow(w: Float, h: Float, t: Float, count: Int) {
    for (i in 0 until count) {
        val x0 = ((i * 41) % 100) / 100f * w
        val phase = ((i * 59) % 100) / 100f
        val p = (t + phase) % 1f
        val x = x0 + sin((p * 2 * PI).toFloat()) * 8.dp.toPx()
        drawCircle(Color(0xCCA9BCD8), (2 + (i % 3)).dp.toPx(), Offset(x, p * h))
    }
}

private fun DrawScope.fog(w: Float, h: Float, t: Float) {
    for (i in 0 until 4) {
        val y = h * (0.2f + i * 0.2f)
        val dx = sin((t * 2 * PI + i).toFloat()) * 18.dp.toPx()
        drawRoundRect(
            Color(0x44B8C4D2), Offset(w * 0.05f + dx, y),
            Size(w * 0.9f, 14.dp.toPx()), CornerRadius(7.dp.toPx())
        )
    }
}

private fun DrawScope.bolt(w: Float, h: Float) {
    val p = Path().apply {
        moveTo(w * 0.5f, h * 0.2f)
        lineTo(w * 0.44f, h * 0.45f)
        lineTo(w * 0.49f, h * 0.45f)
        lineTo(w * 0.45f, h * 0.7f)
        lineTo(w * 0.58f, h * 0.4f)
        lineTo(w * 0.52f, h * 0.4f)
        lineTo(w * 0.56f, h * 0.2f)
        close()
    }
    drawPath(p, Color(0x55FFC93C))
}
