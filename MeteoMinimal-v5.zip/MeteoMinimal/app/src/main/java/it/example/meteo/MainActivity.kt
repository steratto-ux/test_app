package it.example.meteo

import android.Manifest
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    private val pendingDate = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.ensureLoaded(this)
        Pal.systemDark =
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        WeatherWorker.schedule(this)
        if (Settings.rainAlerts) RainAlertWorker.schedule(this)
        pendingDate.value = intent?.getStringExtra(EXTRA_DATE)
        addOnNewIntentListener { i -> pendingDate.value = i.getStringExtra(EXTRA_DATE) }
        setContent { MeteoApp(pendingDate) }
    }

    companion object {
        const val EXTRA_DATE = "date"
    }
}

@Composable
fun MeteoApp(pendingDate: MutableState<String?>, vm: WeatherViewModel = viewModel()) {
    var showMap by rememberSaveable { mutableStateOf(false) }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    // Tema: segue le impostazioni, oppure il tema del telefono
    val systemDark = isSystemInDarkTheme()
    SideEffect { Pal.systemDark = systemDark }
    val dark = Pal.dark
    val activity = LocalContext.current as ComponentActivity
    LaunchedEffect(dark) {
        val style = if (dark) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        } else {
            SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        }
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.load() }

    // Aggiorna i dati ogni volta che l'app viene aperta
    LifecycleEventEffect(Lifecycle.Event.ON_START) { vm.load() }
    LaunchedEffect(Unit) {
        launcher.launch(
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        )
    }

    val f = vm.forecast

    // Giorno scelto toccando il widget (il widget mostra sempre la posizione attuale)
    LaunchedEffect(pendingDate.value, f) {
        val date = pendingDate.value
        if (date != null) {
            if (vm.place != null) {
                vm.selectPlace(null)
                return@LaunchedEffect
            }
            if (f != null) {
                val i = f.days.indexOfFirst { it.date.toString() == date }
                if (i >= 0) {
                    showMap = false
                    showSearch = false
                    showSettings = false
                    vm.selected = i
                }
                pendingDate.value = null
            }
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Box(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
            val sel = vm.selected
            when {
                showSettings -> SettingsScreen(onBack = { showSettings = false })
                showSearch -> SearchScreen(
                    favorites = vm.favorites,
                    current = vm.place,
                    onBack = { showSearch = false },
                    onPick = { p ->
                        vm.selectPlace(p)
                        showSearch = false
                    },
                    onToggleFavorite = { p -> vm.toggleFavorite(p) }
                )
                showMap && f != null -> MapScreen(f.lat, f.lon) { showMap = false }
                f != null && sel != null && sel in f.days.indices -> DetailScreen(f.days[sel]) { vm.selected = null }
                else -> HomeScreen(
                    f, vm.error, vm.refreshing,
                    onRefresh = { vm.load() },
                    onDay = { vm.selected = it },
                    onMap = { showMap = true },
                    onSearch = { showSearch = true },
                    onSettings = { showSettings = true },
                    nowcast = vm.nowcast,
                    air = vm.air
                )
            }
        }
    }
}
