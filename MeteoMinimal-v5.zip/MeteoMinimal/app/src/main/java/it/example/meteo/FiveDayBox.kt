package it.example.meteo

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.format.DateTimeFormatter

@Composable
fun FiveDayBox(f: Forecast, onDay: (Int) -> Unit) {
    val items = f.days.drop(1).take(5)
    if (items.isEmpty()) return
    val dateFmt = DateTimeFormatter.ofPattern("dd/MM")

    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(CardBg)
            .padding(vertical = 16.dp)
    ) {
        T(
            "Prossimi giorni", 16.sp, weight = FontWeight.Medium,
            modifier = Modifier.padding(start = 20.dp, bottom = 12.dp)
        )
        // Giorno, data e icona (toccabili)
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, d ->
                Column(
                    Modifier.weight(1f).clickable { onDay(i + 1) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    T(shortDay(d.date), 15.sp, weight = FontWeight.SemiBold)
                    T(d.date.format(dateFmt), 12.sp, Secondary)
                    Spacer(Modifier.height(8.dp))
                    WeatherIcon(d.code, true, 40.dp)
                }
            }
        }
        // Andamento delle temperature
        DailyTempChart(items)
        // Probabilità di precipitazioni
        Row(Modifier.fillMaxWidth()) {
            items.forEach { d ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.height(56.dp), contentAlignment = Alignment.BottomCenter) {
                        Box(
                            Modifier.width(10.dp)
                                .height((56 * d.pop / 100f).coerceAtLeast(4f).dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(Accent.copy(alpha = 0.4f))
                        )
                    }
                    T("${d.pop}%", 13.sp, Secondary)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        // Icona della notte (toccabile)
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, d ->
                val night = d.hours.lastOrNull()?.code ?: d.code
                Box(
                    Modifier.weight(1f).clickable { onDay(i + 1) },
                    contentAlignment = Alignment.Center
                ) { WeatherIcon(night, false, 36.dp) }
            }
        }
    }
}
