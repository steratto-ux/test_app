package it.example.meteo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch

@Composable
private fun OptionRow(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg).padding(16.dp)) {
        T(title, 16.sp, weight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, label) ->
                val on = value == selected
                Box(
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Accent else Bg)
                        .clickable { onSelect(value) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    T(label, 15.sp, if (on) Color.White else Primary, FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Settings.setRainAlerts(ctx, true)
            RainAlertWorker.schedule(ctx)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        T(
            "←  Indietro", 16.sp, Accent,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(8.dp)
        )
        T("Impostazioni", 24.sp, weight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp))

        OptionRow(
            "Tema",
            listOf("dark" to "Scuro", "light" to "Chiaro", "system" to "Sistema"),
            Settings.theme
        ) { Settings.setTheme(ctx, it) }

        OptionRow(
            "Temperatura",
            listOf("C" to "°C", "F" to "°F"),
            Settings.tempUnit
        ) {
            Settings.setTempUnit(ctx, it)
            scope.launch { WeatherWidget().updateAll(ctx) }
        }

        OptionRow(
            "Vento",
            listOf("kmh" to "km/h", "ms" to "m/s", "mph" to "mph"),
            Settings.windUnit
        ) { Settings.setWindUnit(ctx, it) }

        OptionRow(
            "Aggiornamento in background (dati e widget)",
            listOf("30" to "30 min", "60" to "1 ora", "180" to "3 ore"),
            Settings.refreshMin.toString()
        ) {
            Settings.setRefreshMin(ctx, it.toInt())
            WeatherWorker.schedule(ctx)
        }

        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                T("Avviso di pioggia imminente", 16.sp, weight = FontWeight.Medium)
                T(
                    "Una notifica quando la pioggia sta per arrivare, entro un'ora, nella tua ultima " +
                        "posizione nota. Android può ritardare i controlli per risparmiare batteria.",
                    12.sp, Secondary
                )
            }
            Switch(
                checked = Settings.rainAlerts,
                onCheckedChange = { on ->
                    if (on) {
                        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                            PackageManager.PERMISSION_GRANTED
                        if (needsPermission) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            Settings.setRainAlerts(ctx, true)
                            RainAlertWorker.schedule(ctx)
                        }
                    } else {
                        Settings.setRainAlerts(ctx, false)
                        RainAlertWorker.cancel(ctx)
                    }
                }
            )
        }

        T(
            "Il widget mantiene sempre lo sfondo scuro. Le modifiche si applicano subito.",
            12.sp, Secondary, modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}
