package it.example.meteo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.roundToInt

object WeatherRepository {
    private const val PREFS = "weather"
    private const val KEY = "json"
    private const val BASE = "https://api.open-meteo.com/v1/forecast?"

    // Modello italiano ad alta risoluzione (ItaliaMeteo ARPAE ICON-2I, ~2 km, 3 giorni)
    // con ripiego automatico sul miglior modello disponibile per i giorni successivi.
    private val MODELS = listOf("italia_meteo_arpae_icon_2i", "best_match")

    private fun query(lat: Double, lon: Double, withModels: Boolean, extended: Boolean): String {
        val cur = "temperature_2m,apparent_temperature,weather_code,is_day" +
            (if (extended) ",wind_speed_10m,wind_direction_10m,wind_gusts_10m,pressure_msl,visibility,dew_point_2m,uv_index" else "")
        val hourly = "temperature_2m,precipitation_probability,weather_code,relative_humidity_2m" +
            (if (extended) ",pressure_msl,visibility,dew_point_2m" else "")
        val daily = "weather_code,temperature_2m_max,temperature_2m_min," +
            "precipitation_probability_max,sunrise,sunset" +
            (if (extended) ",uv_index_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant" else "")
        return "latitude=$lat&longitude=$lon&current=$cur&hourly=$hourly&daily=$daily" +
            "&timezone=auto&forecast_days=7" +
            (if (withModels) "&models=${MODELS.joinToString(",")}" else "")
    }

    private fun httpGet(url: String, timeoutMs: Int = 12000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        conn.setRequestProperty("User-Agent", "MeteoMinimal/1.4 (app personale)")
        try {
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    // Prova prima modello italiano + dati estesi, poi solo il miglior modello, infine i dati di base
    private fun fetchText(lat: Double, lon: Double): String {
        val attempts = listOf(true to true, false to true, false to false)
        var last: Exception? = null
        for ((models, extended) in attempts) {
            try {
                return httpGet(BASE + query(lat, lon, models, extended)).also { parse(it, "", 0L) }
            } catch (ex: Exception) {
                last = ex
            }
        }
        throw last ?: RuntimeException("errore di rete")
    }

    suspend fun fetch(ctx: Context, lat: Double, lon: Double): Forecast = withContext(Dispatchers.IO) {
        val text = fetchText(lat, lon)
        val place = resolvePlace(ctx, lat, lon)
        val now = System.currentTimeMillis()
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, text)
            .putLong("ts", now)
            .apply()
        parse(text, place, now)
    }

    // Previsioni per una località scelta (non tocca i dati usati dal widget)
    suspend fun fetchPlace(lat: Double, lon: Double, name: String): Forecast = withContext(Dispatchers.IO) {
        parse(fetchText(lat, lon), name, System.currentTimeMillis())
    }

    fun cached(ctx: Context): Forecast? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val text = p.getString(KEY, null) ?: return null
        return runCatching {
            parse(text, p.getString("place", "Posizione attuale") ?: "Posizione attuale", p.getLong("ts", 0L))
        }.getOrNull()
    }

    // Nome della località tramite Nominatim (OpenStreetMap); richiesto di nuovo solo se ci si sposta.
    private fun resolvePlace(ctx: Context, lat: Double, lon: Double): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = p.getString("place", null)
        val lastLat = p.getFloat("pl_lat", 999f).toDouble()
        val lastLon = p.getFloat("pl_lon", 999f).toDouble()
        if (saved != null && abs(lat - lastLat) < 0.02 && abs(lon - lastLon) < 0.02) return saved
        return try {
            val url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12" +
                "&accept-language=it&lat=$lat&lon=$lon"
            val addr = JSONObject(httpGet(url, 8000)).getJSONObject("address")
            val name = listOf("city", "town", "village", "municipality", "hamlet", "suburb", "county")
                .firstNotNullOfOrNull { k -> addr.optString(k, "").takeIf { it.isNotBlank() } }
            if (name != null) {
                p.edit().putString("place", name)
                    .putFloat("pl_lat", lat.toFloat()).putFloat("pl_lon", lon.toFloat()).apply()
                name
            } else saved ?: "Posizione attuale"
        } catch (e: Exception) {
            saved ?: "Posizione attuale"
        }
    }

    private fun keys(name: String): List<String> = MODELS.map { "${name}_$it" } + name

    // Unisce le serie dei vari modelli: per ogni ora usa il primo valore disponibile.
    private fun JSONObject.nums(name: String, required: Boolean = true): List<Double?> {
        val sources = keys(name).mapNotNull { optJSONArray(it) }
        if (sources.isEmpty()) {
            if (required) throw JSONException("missing $name")
            return emptyList()
        }
        val n = sources.maxOf { it.length() }
        return List(n) { i ->
            sources.firstNotNullOfOrNull { a: JSONArray -> if (i < a.length() && !a.isNull(i)) a.getDouble(i) else null }
        }
    }

    private fun JSONObject.strs(name: String): List<String?> {
        val sources = keys(name).mapNotNull { optJSONArray(it) }
        if (sources.isEmpty()) throw JSONException("missing $name")
        val n = sources.maxOf { it.length() }
        return List(n) { i ->
            sources.firstNotNullOfOrNull { a: JSONArray -> if (i < a.length() && !a.isNull(i)) a.getString(i) else null }
        }
    }

    private fun JSONObject.scalar(name: String): Double? =
        keys(name).firstNotNullOfOrNull { k -> if (has(k) && !isNull(k)) getDouble(k) else null }

    private fun List<Double?>.avgOf(from: Int, to: Int): Double {
        if (from >= size) return Double.NaN
        val vals = subList(from, minOf(to, size)).filterNotNull()
        return if (vals.isEmpty()) Double.NaN else vals.average()
    }

    private fun parse(text: String, place: String, ts: Long): Forecast {
        val root = JSONObject(text)
        val cur = root.getJSONObject("current")
        val d = root.getJSONObject("daily")
        val h = root.getJSONObject("hourly")

        val dateArr = d.getJSONArray("time")
        val dates = List(dateArr.length()) { dateArr.getString(it) }
        val codes = d.nums("weather_code")
        val tMax = d.nums("temperature_2m_max")
        val tMin = d.nums("temperature_2m_min")
        val pop = d.nums("precipitation_probability_max", false)
        val sunrise = d.strs("sunrise")
        val sunset = d.strs("sunset")
        val uvMax = d.nums("uv_index_max", false)
        val wMax = d.nums("wind_speed_10m_max", false)
        val gMax = d.nums("wind_gusts_10m_max", false)
        val wDir = d.nums("wind_direction_10m_dominant", false)

        val hTemp = h.nums("temperature_2m")
        val hPop = h.nums("precipitation_probability", false)
        val hCode = h.nums("weather_code")
        val hHum = h.nums("relative_humidity_2m", false)
        val hPress = h.nums("pressure_msl", false)
        val hVis = h.nums("visibility", false)
        val hDew = h.nums("dew_point_2m", false)
        val anyTemp = hTemp.filterNotNull().firstOrNull() ?: 0.0

        val days = dates.indices.map { i ->
            val from = i * 24
            val to = minOf(from + 24, hTemp.size)
            val hours = (from until to).map { idx ->
                Hour(
                    LocalTime.of(idx - from, 0),
                    hTemp[idx] ?: anyTemp,
                    (hPop.getOrNull(idx) ?: 0.0).roundToInt(),
                    (hCode.getOrNull(idx) ?: 0.0).roundToInt()
                )
            }
            val hums = if (to > from) hHum.subList(minOf(from, hHum.size), minOf(to, hHum.size)).filterNotNull() else emptyList()
            Day(
                date = LocalDate.parse(dates[i]),
                code = (codes.getOrNull(i) ?: 0.0).roundToInt(),
                tMax = tMax.getOrNull(i) ?: hours.maxOfOrNull { it.temp } ?: anyTemp,
                tMin = tMin.getOrNull(i) ?: hours.minOfOrNull { it.temp } ?: anyTemp,
                pop = (pop.getOrNull(i) ?: hours.maxOfOrNull { it.pop }?.toDouble() ?: 0.0).roundToInt(),
                humidity = if (hums.isEmpty()) 0 else hums.average().roundToInt(),
                sunrise = sunrise.getOrNull(i)?.let { LocalDateTime.parse(it).toLocalTime() } ?: LocalTime.of(7, 0),
                sunset = sunset.getOrNull(i)?.let { LocalDateTime.parse(it).toLocalTime() } ?: LocalTime.of(18, 0),
                hours = hours,
                windMax = wMax.getOrNull(i) ?: Double.NaN,
                gustMax = gMax.getOrNull(i) ?: Double.NaN,
                windDir = wDir.getOrNull(i) ?: Double.NaN,
                uvMax = uvMax.getOrNull(i) ?: Double.NaN,
                pressure = hPress.avgOf(from, to),
                visKm = hVis.avgOf(from, to) / 1000.0,
                dew = hDew.avgOf(from, to)
            )
        }
        val localTime = runCatching { LocalDateTime.parse(cur.getString("time")).toLocalTime() }.getOrNull()
            ?: LocalTime.now()
        return Forecast(
            currentTemp = cur.scalar("temperature_2m") ?: anyTemp,
            feelsLike = cur.scalar("apparent_temperature") ?: cur.scalar("temperature_2m") ?: anyTemp,
            currentCode = (cur.scalar("weather_code") ?: 0.0).roundToInt(),
            isDay = (cur.scalar("is_day") ?: 1.0) == 1.0,
            days = days,
            lat = root.optDouble("latitude", 41.9),
            lon = root.optDouble("longitude", 12.5),
            place = place,
            updatedAt = ts,
            windSpeed = cur.scalar("wind_speed_10m") ?: Double.NaN,
            windGust = cur.scalar("wind_gusts_10m") ?: Double.NaN,
            windDir = cur.scalar("wind_direction_10m") ?: Double.NaN,
            pressure = cur.scalar("pressure_msl") ?: Double.NaN,
            visKm = (cur.scalar("visibility") ?: Double.NaN) / 1000.0,
            dew = cur.scalar("dew_point_2m") ?: Double.NaN,
            uv = cur.scalar("uv_index") ?: Double.NaN,
            localTime = localTime
        )
    }
}
