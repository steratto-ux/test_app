package it.example.meteo

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val timeFmt2 = DateTimeFormatter.ofPattern("HH:mm")

@Composable
private fun CardBox(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardBg).padding(16.dp)
    ) { content() }
}

// ---------- riquadri di informazione ------------------------------------------

private data class Tile(val label: String, val value: String, val sub: String? = null, val dir: Double? = null)

@Composable
fun WindCompass(dirFrom: Double, modifier: Modifier = Modifier.size(40.dp)) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f - 2.dp.toPx()
        drawCircle(Secondary.copy(alpha = 0.5f), r, c, style = Stroke(1.5.dp.toPx()))
        val a = Math.toRadians(dirFrom + 180.0)   // verso cui soffia il vento
        val dx = sin(a).toFloat()
        val dy = -cos(a).toFloat()
        val tip = Offset(c.x + dx * r * 0.8f, c.y + dy * r * 0.8f)
        val tail = Offset(c.x - dx * r * 0.6f, c.y - dy * r * 0.6f)
        drawLine(Accent, tail, tip, strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        val wl = r * 0.35f
        for (sign in listOf(-1.0, 1.0)) {
            val b = a + PI + sign * 0.5
            val wing = Offset(tip.x + wl * sin(b).toFloat(), tip.y - wl * cos(b).toFloat())
            drawLine(Accent, tip, wing, strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun InfoTile(label: String, value: String, sub: String?, modifier: Modifier, dir: Double?) {
    Row(
        modifier.clip(RoundedCornerShape(18.dp)).background(Bg).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T(label, 12.sp, Secondary)
            T(value, 17.sp, weight = FontWeight.SemiBold)
            if (sub != null) T(sub, 12.sp, Secondary)
        }
        if (dir != null) WindCompass(dir)
    }
}

@Composable
private fun TileGrid(tiles: List<Tile>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { t ->
                    InfoTile(t.label, t.value, t.sub, Modifier.weight(1f), t.dir)
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

private fun uvLabel(v: Double): String = when {
    v < 3 -> "Basso"
    v < 6 -> "Moderato"
    v < 8 -> "Alto"
    v < 11 -> "Molto alto"
    else -> "Estremo"
}

private fun visText(km: Double): String =
    if (km >= 10) "${km.roundToInt()} km" else String.format(Locale.ITALIAN, "%.1f km", km)

private fun tilesFor(
    wind: Double, gust: Double, dir: Double, uv: Double,
    pressure: Double, vis: Double, dew: Double, daily: Boolean
): List<Tile> = buildList {
    if (!wind.isNaN()) {
        add(
            Tile(
                if (daily) "Vento max" else "Vento", windText(wind),
                if (dir.isNaN()) null else "da ${cardinal(dir)}",
                if (dir.isNaN()) null else dir
            )
        )
    }
    if (!gust.isNaN()) add(Tile(if (daily) "Raffiche max" else "Raffiche", windText(gust)))
    if (!uv.isNaN()) add(Tile(if (daily) "Indice UV max" else "Indice UV", "${uv.roundToInt()}", uvLabel(uv)))
    if (!pressure.isNaN()) add(Tile("Pressione", "${pressure.roundToInt()} hPa"))
    if (!vis.isNaN()) add(Tile("Visibilità", visText(vis)))
    if (!dew.isNaN()) add(Tile("Punto di rugiada", dew.deg()))
}

@Composable
fun DetailsCard(f: Forecast) {
    val tiles = tilesFor(f.windSpeed, f.windGust, f.windDir, f.uv, f.pressure, f.visKm, f.dew, false)
    if (tiles.isEmpty()) return
    CardBox {
        T("Condizioni attuali", 16.sp, weight = FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        TileGrid(tiles)
    }
}

@Composable
fun DayDetailsCard(day: Day) {
    val tiles = tilesFor(day.windMax, day.gustMax, day.windDir, day.uvMax, day.pressure, day.visKm, day.dew, true)
    if (tiles.isEmpty()) return
    CardBox {
        T("Dettagli del giorno", 16.sp, weight = FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        TileGrid(tiles)
    }
}

// ---------- pioggia nelle prossime 2 ore --------------------------------------

@Composable
fun NowcastCard(mm: List<Double>) {
    CardBox {
        T("Prossime 2 ore", 16.sp, weight = FontWeight.Medium)
        T(nowcastSummary(mm), 14.sp, Secondary, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(12.dp))
        Canvas(Modifier.fillMaxWidth().height(56.dp)) {
            val n = mm.size
            val gap = 6.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            mm.forEachIndexed { i, v ->
                val frac = (v / 1.5).coerceIn(0.0, 1.0).toFloat()
                val bh = max(3.dp.toPx(), size.height * frac)
                drawRoundRect(
                    Accent.copy(alpha = if (v >= 0.1) 0.9f else 0.25f),
                    Offset(i * (bw + gap), size.height - bh),
                    Size(bw, bh),
                    CornerRadius(bw / 2f)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("ora", 11.sp, Secondary)
            T("+1 h", 11.sp, Secondary)
            T("+2 h", 11.sp, Secondary)
        }
    }
}

// ---------- qualità dell'aria e pollini ---------------------------------------

private fun aqiColor(v: Int): Color = when {
    v <= 20 -> Color(0xFF4CAF50)
    v <= 40 -> Color(0xFF9CCC65)
    v <= 60 -> Color(0xFFFFC107)
    v <= 80 -> Color(0xFFFF9800)
    v <= 100 -> Color(0xFFF44336)
    else -> Color(0xFF8E24AA)
}

private fun aqiLabel(v: Int): String = when {
    v <= 20 -> "Buona"
    v <= 40 -> "Discreta"
    v <= 60 -> "Moderata"
    v <= 80 -> "Scadente"
    v <= 100 -> "Molto scadente"
    else -> "Pessima"
}

@Composable
fun AirCard(a: AirQuality) {
    val gases = buildList {
        a.pm25?.let { add(Tile("PM2.5", "${it.roundToInt()} µg/m³")) }
        a.pm10?.let { add(Tile("PM10", "${it.roundToInt()} µg/m³")) }
        a.o3?.let { add(Tile("Ozono", "${it.roundToInt()} µg/m³")) }
        a.no2?.let { add(Tile("Biossido di azoto", "${it.roundToInt()} µg/m³")) }
    }
    if (a.aqi == null && gases.isEmpty() && a.pollen.isEmpty()) return
    CardBox {
        T("Qualità dell'aria", 16.sp, weight = FontWeight.Medium)
        if (a.aqi != null) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(aqiColor(a.aqi)),
                    contentAlignment = Alignment.Center
                ) {
                    T(
                        "${a.aqi}", 22.sp,
                        if (a.aqi <= 60) Color(0xFF1A2029) else Color.White,
                        FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    T(aqiLabel(a.aqi), 18.sp, weight = FontWeight.SemiBold)
                    T("Indice europeo (EAQI)", 12.sp, Secondary)
                }
            }
        }
        if (gases.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            TileGrid(gases)
        }
        if (a.pollen.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            T("Pollini (granuli per m³)", 14.sp, Secondary)
            Spacer(Modifier.height(8.dp))
            TileGrid(a.pollen.map { Tile(it.first, "${it.second.roundToInt()}") })
        }
    }
}

// ---------- sole e luna --------------------------------------------------------

private fun moonFraction(date: LocalDate): Double {
    val days = date.toEpochDay() + 0.5 - 10962.76   // luna nuova del 6 gennaio 2000
    val f = (days / 29.530588853) % 1.0
    return if (f < 0) f + 1.0 else f
}

private fun moonName(f: Double): String = when {
    f < 0.03 || f >= 0.97 -> "Luna nuova"
    f < 0.22 -> "Luna crescente"
    f < 0.28 -> "Primo quarto"
    f < 0.47 -> "Gibbosa crescente"
    f < 0.53 -> "Luna piena"
    f < 0.72 -> "Gibbosa calante"
    f < 0.78 -> "Ultimo quarto"
    else -> "Luna calante"
}

@Composable
private fun MoonIcon(f: Double, modifier: Modifier = Modifier.size(44.dp)) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f - 1.dp.toPx()
        drawCircle(Color(0xFF3A4556), r, c)
        val k = cos(2.0 * PI * f)
        val kx = (abs(k) * r).toFloat().coerceAtLeast(0.5f)
        val path = Path().apply {
            arcTo(Rect(c.x - r, c.y - r, c.x + r, c.y + r), -90f, 180f, true)
            if (k >= 0) {
                arcTo(Rect(c.x - kx, c.y - r, c.x + kx, c.y + r), 90f, -180f, false)
            } else {
                arcTo(Rect(c.x - kx, c.y - r, c.x + kx, c.y + r), 90f, 180f, false)
            }
            close()
        }
        val lit = Color(0xFFF5E6A8)
        if (f < 0.5) {
            drawPath(path, lit)
        } else {
            scale(-1f, 1f, c) { drawPath(path, lit) }
        }
    }
}

@Composable
fun SunMoonCard(day: Day, now: LocalTime?) {
    val total = Duration.between(day.sunrise, day.sunset).toMinutes()
    val progress = if (now != null && total > 0) {
        Duration.between(day.sunrise, now).toMinutes().toDouble() / total
    } else {
        -1.0
    }
    val moon = moonFraction(day.date)
    val illum = ((1.0 - cos(2.0 * PI * moon)) / 2.0 * 100).roundToInt()

    CardBox {
        T("Sole e luna", 16.sp, weight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().height(96.dp)) {
            val track = Secondary.copy(alpha = 0.45f)
            val sunCol = Color(0xFFFFB300)
            val pad = 24.dp.toPx()
            val r = min((size.width - 2 * pad) / 2f, size.height - 16.dp.toPx())
            val cx = size.width / 2f
            val cy = size.height - 12.dp.toPx()
            val tl = Offset(cx - r, cy - r)
            val sz = Size(2 * r, 2 * r)
            drawLine(track, Offset(cx - r - 12.dp.toPx(), cy), Offset(cx + r + 12.dp.toPx(), cy), 1.5.dp.toPx())
            drawArc(
                color = track, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                topLeft = tl, size = sz,
                style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f))
            )
            if (progress in 0.0..1.0) {
                drawArc(
                    color = sunCol, startAngle = 180f, sweepAngle = (180.0 * progress).toFloat(),
                    useCenter = false, topLeft = tl, size = sz,
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                )
                val th = PI * (1.0 - progress)
                drawCircle(
                    sunCol, 8.dp.toPx(),
                    Offset(cx + r * cos(th).toFloat(), cy - r * sin(th).toFloat())
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                T("Alba", 12.sp, Secondary)
                T(day.sunrise.format(timeFmt2), 16.sp, weight = FontWeight.SemiBold)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                T("Durata del giorno", 12.sp, Secondary)
                T("${total / 60} h ${total % 60} min", 16.sp, weight = FontWeight.SemiBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                T("Tramonto", 12.sp, Secondary)
                T(day.sunset.format(timeFmt2), 16.sp, weight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            MoonIcon(moon)
            Spacer(Modifier.width(12.dp))
            Column {
                T(moonName(moon), 16.sp, weight = FontWeight.SemiBold)
                T("Illuminata al $illum%", 12.sp, Secondary)
            }
        }
    }
}
