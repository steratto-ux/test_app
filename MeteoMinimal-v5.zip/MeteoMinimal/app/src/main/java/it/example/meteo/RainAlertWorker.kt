package it.example.meteo

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

class RainAlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        Settings.ensureLoaded(ctx)
        if (!Settings.rainAlerts) return Result.success()

        val (lat, lon) = LocationHelper.saved(ctx)
        val mm = try {
            NowcastRepository.fetch(lat, lon)
        } catch (e: Exception) {
            return Result.retry()
        }
        if (mm == null || mm.size < 2) return Result.success()

        val prefs = ctx.getSharedPreferences("rain_alert", Context.MODE_PRIVATE)
        val dryNow = mm[0] < 0.1
        val first = mm.indexOfFirst { it >= 0.1 }
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last", 0L)
        // Avvisa solo se ora è asciutto e la pioggia arriva entro un'ora; al massimo una volta ogni 3 ore
        if (dryNow && first in 1..4 && now - last > 3 * 3600_000L) {
            val place = WeatherRepository.cached(ctx)?.place ?: "la tua zona"
            notifyRain(ctx, first * 15, place)
            prefs.edit().putLong("last", now).apply()
        }
        return Result.success()
    }

    private fun notifyRain(ctx: Context, minutes: Int, place: String) {
        val mgr = NotificationManagerCompat.from(ctx)
        if (!mgr.areNotificationsEnabled()) return
        mgr.createNotificationChannel(
            NotificationChannelCompat.Builder("rain", NotificationManagerCompat.IMPORTANCE_DEFAULT)
                .setName("Avvisi di pioggia")
                .build()
        )
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, "rain")
            .setSmallIcon(R.drawable.ic_rain)
            .setContentTitle("Pioggia in arrivo")
            .setContentText("A $place tra circa $minutes minuti")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            mgr.notify(1001, n)
        } catch (e: SecurityException) {
            // permesso notifiche non concesso
        }
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<RainAlertWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("rain_alert", ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork("rain_alert")
        }
    }
}
