package it.example.meteo

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(
    favorites: List<Place>,
    current: Place?,
    onBack: () -> Unit,
    onPick: (Place?) -> Unit,
    onToggleFavorite: (Place) -> Unit
) {
    BackHandler(onBack = onBack)
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        failed = false
        val q = query.trim()
        if (q.length < 2) {
            results = emptyList()
            searching = false
            return@LaunchedEffect
        }
        searching = true
        delay(350)
        try {
            results = GeoRepository.search(q)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            results = emptyList()
            failed = true
        }
        searching = false
    }

    Column(Modifier.fillMaxSize().imePadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            T(
                "←  Indietro", 16.sp, Accent,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(8.dp)
            )
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { T("Cerca una località…", 16.sp, Secondary) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (query.isBlank()) {
                item {
                    PlaceRow(
                        "Posizione attuale",
                        if (current == null) "In uso · GPS del telefono" else "GPS del telefono",
                        null, { onPick(null) }, null
                    )
                }
                item { T("Preferiti", 14.sp, Secondary, modifier = Modifier.padding(top = 8.dp, start = 4.dp)) }
                if (favorites.isEmpty()) {
                    item {
                        T(
                            "Nessun preferito. Cerca una località e tocca la stella per aggiungerla.",
                            14.sp, Secondary, modifier = Modifier.padding(4.dp)
                        )
                    }
                }
                items(favorites) { p ->
                    val inUse = current != null && current.sameAs(p)
                    PlaceRow(
                        p.name,
                        if (inUse) p.subtitle + " · in uso" else p.subtitle,
                        true, { onPick(p) }, { onToggleFavorite(p) }
                    )
                }
            } else {
                if (searching && results.isEmpty()) {
                    item { T("Ricerca in corso…", 14.sp, Secondary, modifier = Modifier.padding(4.dp)) }
                } else if (failed) {
                    item {
                        T(
                            "Ricerca non disponibile. Controlla la connessione.",
                            14.sp, Secondary, modifier = Modifier.padding(4.dp)
                        )
                    }
                } else if (results.isEmpty()) {
                    item { T("Nessun risultato", 14.sp, Secondary, modifier = Modifier.padding(4.dp)) }
                }
                items(results) { p ->
                    PlaceRow(
                        p.name, p.subtitle,
                        favorites.any { it.sameAs(p) }, { onPick(p) }, { onToggleFavorite(p) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PlaceRow(
    title: String,
    subtitle: String,
    starred: Boolean?,
    onClick: () -> Unit,
    onStar: (() -> Unit)?
) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T(title, 17.sp, weight = FontWeight.Medium)
            if (subtitle.isNotBlank()) T(subtitle, 13.sp, Secondary)
        }
        if (starred != null && onStar != null) {
            T(
                if (starred) "★" else "☆", 28.sp, Color(0xFFFFC93C),
                modifier = Modifier.clip(CircleShape).clickable(onClick = onStar).padding(8.dp)
            )
        }
    }
}
