package it.example.meteo

import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalContext
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.RowScope
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import kotlin.math.roundToInt

private val WHITE = ColorProvider(Color.White)
private val GRAY = ColorProvider(Color(0xFF9AA5B4))
private val BLUE = ColorProvider(Color(0xFF6FB4FF))

class WeatherWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Single

    override suspend fun provideGlance(context: android.content.Context, id: GlanceId) {
        Settings.ensureLoaded(context)
        val forecast = WeatherRepository.cached(context)
        provideContent { Content(forecast) }
    }

    @Composable
    private fun Content(f: Forecast?) {
        val ctx = LocalContext.current
        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(ColorProvider(Color(0xFF14181F)))
                .cornerRadius(22.dp)
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clickable(actionStartActivity(Intent(ctx, MainActivity::class.java)))
        ) {
            if (f == null || f.days.isEmpty()) {
                Text("Apri l'app per caricare il meteo", style = TextStyle(color = WHITE, fontSize = 14.sp))
            } else {
                val today = f.days.first()
                // Riga alta: situazione attuale
                Row(
                    modifier = GlanceModifier.fillMaxWidth().defaultWeight(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        provider = ImageProvider(iconFor(f.currentCode, f.isDay)),
                        contentDescription = null,
                        modifier = GlanceModifier.size(60.dp)
                    )
                    Spacer(GlanceModifier.width(8.dp))
                    Column {
                        Text(
                            f.currentTemp.deg(),
                            style = TextStyle(color = WHITE, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Min ${today.tMin.deg()}  Max ${today.tMax.deg()}",
                            style = TextStyle(color = GRAY, fontSize = 11.sp)
                        )
                    }
                    Spacer(GlanceModifier.defaultWeight())
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            f.place,
                            style = TextStyle(color = WHITE, fontSize = 13.sp, fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                        Text("Pioggia ${today.pop}%", style = TextStyle(color = BLUE, fontSize = 11.sp))
                        Text(
                            "Agg. ${updatedShort(f.updatedAt)}",
                            style = TextStyle(color = GRAY, fontSize = 10.sp)
                        )
                    }
                }
                // Riga bassa: i 4 giorni successivi
                Row(modifier = GlanceModifier.fillMaxWidth()) {
                    f.days.drop(1).take(4).forEach { DayCell(it) }
                }
            }
        }
    }

    @Composable
    private fun RowScope.DayCell(d: Day) {
        val ctx = LocalContext.current
        val intent = Intent(ctx, MainActivity::class.java).apply {
            data = Uri.parse("meteo://day/${d.date}")
            putExtra(MainActivity.EXTRA_DATE, d.date.toString())
        }
        Column(
            modifier = GlanceModifier.defaultWeight().clickable(actionStartActivity(intent)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(shortDay(d.date), style = TextStyle(color = GRAY, fontSize = 11.sp))
            Image(
                provider = ImageProvider(iconFor(d.code)),
                contentDescription = null,
                modifier = GlanceModifier.size(26.dp)
            )
            Text(
                "${d.tMin.deg()} / ${d.tMax.deg()}",
                style = TextStyle(color = WHITE, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            )
        }
    }
}

class WeatherWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = WeatherWidget()

    override fun onEnabled(context: android.content.Context) {
        super.onEnabled(context)
        WeatherWorker.schedule(context)
    }
}
