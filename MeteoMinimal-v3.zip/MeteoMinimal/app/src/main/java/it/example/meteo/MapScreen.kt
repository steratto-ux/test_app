package it.example.meteo

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.tan

private const val TILE_DP = 256.0
private const val MIN_ZOOM = 5.0
private const val MAX_ZOOM = 15.0
private const val GRID_N = 5
private const val GRID_STEP = 0.15

private data class TileRef(val z: Int, val x: Int, val y: Int)

private class MapData(
    val times: List<String>,
    val lats: List<Double>,
    val lons: List<Double>,
    val stepLat: Double,
    val stepLon: Double,
    val precip: List<List<Double>>,
    val cloud: List<List<Double>>
)

private fun worldX(lon: Double): Double = (lon + 180.0) / 360.0

private fun worldY(lat: Double): Double {
    val r = Math.toRadians(lat.coerceIn(-85.0, 85.0))
    return (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0
}

private fun rainColor(r: Double): Color = when {
    r < 0.5 -> Color(0xFFFFF176)
    r < 1.0 -> Color(0xFFFFD600)
    r < 2.5 -> Color(0xFFFFA000)
    r < 5.0 -> Color(0xFFF4511E)
    else -> Color(0xFFD50000)
}

private fun downloadTile(z: Int, x: Int, y: Int): ImageBitmap? {
    val urls = listOf(
        "https://${"abc"[(x + y) % 3]}.tile.opentopomap.org/$z/$x/$y.png",
        "https://tile.openstreetmap.org/$z/$x/$y.png"
    )
    for (u in urls) {
        try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "MeteoMinimal/1.2 (app personale)")
            try {
                if (c.responseCode == 200) {
                    val bmp = BitmapFactory.decodeStream(c.inputStream)
                    if (bmp != null) return bmp.asImageBitmap()
                }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            // prova il server successivo
        }
    }
    return null
}

private suspend fun fetchMapData(lat: Double, lon: Double): MapData = withContext(Dispatchers.IO) {
    val stepLon = GRID_STEP / cos(Math.toRadians(lat))
    val lats = ArrayList<Double>()
    val lons = ArrayList<Double>()
    for (i in -GRID_N..GRID_N) {
        for (j in -GRID_N..GRID_N) {
            lats.add(lat + i * GRID_STEP)
            lons.add(lon + j * stepLon)
        }
    }
    val url = "https://api.open-meteo.com/v1/forecast?latitude=" +
        lats.joinToString(",") { "%.3f".format(Locale.US, it) } +
        "&longitude=" + lons.joinToString(",") { "%.3f".format(Locale.US, it) } +
        "&hourly=precipitation,cloud_cover&forecast_hours=13&timezone=auto"
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15000
    conn.readTimeout = 15000
    conn.setRequestProperty("User-Agent", "MeteoMinimal/1.2 (app personale)")
    val text = try {
        if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
        conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
    val arr = if (text.trimStart().startsWith("[")) JSONArray(text) else JSONArray().put(JSONObject(text))
    val tArr = arr.getJSONObject(0).getJSONObject("hourly").getJSONArray("time")
    val times = List(tArr.length()) { tArr.getString(it) }
    val precip = ArrayList<List<Double>>()
    val cloud = ArrayList<List<Double>>()
    for (k in 0 until arr.length()) {
        val hr = arr.getJSONObject(k).getJSONObject("hourly")
        val p = hr.getJSONArray("precipitation")
        val c = hr.getJSONArray("cloud_cover")
        precip.add(List(times.size) { if (p.isNull(it)) 0.0 else p.getDouble(it) })
        cloud.add(List(times.size) { if (c.isNull(it)) 0.0 else c.getDouble(it) })
    }
    MapData(times, lats, lons, GRID_STEP, stepLon, precip, cloud)
}

private fun mapTime(t: String, h: Int): String =
    t.substring(8, 10) + "/" + t.substring(5, 7) + " ore " + t.substring(11, 16) + (if (h == 0) " (adesso)" else "")

@Composable
private fun ZoomButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xE60F1318)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(label, 22.sp) }
}

@Composable
fun MapScreen(lat: Double, lon: Double, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val dens = LocalDensity.current.density

    var wx by remember { mutableStateOf(worldX(lon)) }
    var wy by remember { mutableStateOf(worldY(lat)) }
    var zoom by remember { mutableStateOf(8.5) }
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    var data by remember { mutableStateOf<MapData?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var hour by remember { mutableStateOf(0) }
    var showClouds by remember { mutableStateOf(true) }
    var showRain by remember { mutableStateOf(true) }
    val tiles = remember { mutableStateMapOf<String, ImageBitmap>() }
    val loading = remember { HashSet<String>() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(lat, lon) {
        try {
            data = fetchMapData(lat, lon)
        } catch (e: Exception) {
            error = e.message ?: "errore di rete"
        }
    }

    val w = viewSize.width.toFloat()
    val h = viewSize.height.toFloat()
    val tz = zoom.roundToInt().coerceIn(3, 15)
    val n = 1 shl tz
    val scalePx = TILE_DP * dens * 2.0.pow(zoom)
    val tilePx = TILE_DP * dens * 2.0.pow(zoom - tz)

    val visible: List<TileRef> = if (w <= 0f || h <= 0f) {
        emptyList()
    } else {
        val x0 = floor((wx - w / 2 / scalePx) * n).toInt()
        val x1 = floor((wx + w / 2 / scalePx) * n).toInt()
        val y0 = max(0, floor((wy - h / 2 / scalePx) * n).toInt())
        val y1 = min(n - 1, floor((wy + h / 2 / scalePx) * n).toInt())
        val list = ArrayList<TileRef>()
        for (ty in y0..y1) {
            for (tx in x0..x1) {
                if (list.size < 80) list.add(TileRef(tz, tx, ty))
            }
        }
        list
    }

    LaunchedEffect(visible) {
        if (tiles.size > 300) tiles.clear()
        for (t in visible) {
            val x = ((t.x % n) + n) % n
            val key = "${t.z}/$x/${t.y}"
            if (tiles.containsKey(key) || !loading.add(key)) continue
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { downloadTile(t.z, x, t.y) }
                if (bmp != null) tiles[key] = bmp
                loading.remove(key)
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            T(
                "←  Indietro", 16.sp, Accent,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(8.dp)
            )
            T("Nuvole e precipitazioni", 16.sp, weight = FontWeight.Medium, modifier = Modifier.padding(end = 8.dp))
        }

        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            Canvas(
                Modifier.fillMaxSize()
                    .background(Color(0xFF1A2029))
                    .onSizeChanged { viewSize = it }
                    .pointerInput(Unit) {
                        detectTransformGestures { centroid, pan, zoomChange, _ ->
                            val oldScale = TILE_DP * dens * 2.0.pow(zoom)
                            val newZoom = (zoom + ln(zoomChange.toDouble()) / ln(2.0)).coerceIn(MIN_ZOOM, MAX_ZOOM)
                            val newScale = TILE_DP * dens * 2.0.pow(newZoom)
                            val cw = size.width / 2.0
                            val ch = size.height / 2.0
                            val wxc = wx + (centroid.x - cw) / oldScale
                            val wyc = wy + (centroid.y - ch) / oldScale
                            wx = wxc - (centroid.x + pan.x - cw) / newScale
                            wy = wyc - (centroid.y + pan.y - ch) / newScale
                            zoom = newZoom
                        }
                    }
            ) {
                fun px(lonV: Double): Float = (w / 2 + (worldX(lonV) - wx) * scalePx).toFloat()
                fun py(latV: Double): Float = (h / 2 + (worldY(latV) - wy) * scalePx).toFloat()

                // Mappa topografica
                for (t in visible) {
                    val x = ((t.x % n) + n) % n
                    val img = tiles["${t.z}/$x/${t.y}"] ?: continue
                    val sx = w / 2 + (t.x.toDouble() / n - wx) * scalePx
                    val sy = h / 2 + (t.y.toDouble() / n - wy) * scalePx
                    val side = ceil(tilePx).toInt() + 1
                    drawImage(
                        img,
                        dstOffset = IntOffset(sx.roundToInt(), sy.roundToInt()),
                        dstSize = IntSize(side, side)
                    )
                }

                // Nuvole e precipitazioni
                val d = data
                if (d != null && hour in d.times.indices) {
                    for (pass in 0..1) {
                        for (k in d.lats.indices) {
                            val left = px(d.lons[k] - d.stepLon / 2)
                            val right = px(d.lons[k] + d.stepLon / 2)
                            val top = py(d.lats[k] + d.stepLat / 2)
                            val bottom = py(d.lats[k] - d.stepLat / 2)
                            val sz = Size(right - left + 1f, bottom - top + 1f)
                            if (pass == 0 && showClouds) {
                                val c = d.cloud[k][hour]
                                if (c > 10.0) {
                                    val a = min(0.5f, (c / 100.0 * 0.5).toFloat())
                                    drawRect(Color(0xFF6B7B8C).copy(alpha = a), Offset(left, top), sz)
                                }
                            }
                            if (pass == 1 && showRain) {
                                val r = d.precip[k][hour]
                                if (r >= 0.1) {
                                    drawRect(rainColor(r).copy(alpha = 0.7f), Offset(left, top), sz)
                                }
                            }
                        }
                    }
                }

                // La tua posizione
                val c = Offset(px(lon), py(lat))
                drawCircle(Color.White, 9.dp.toPx(), c)
                drawCircle(Color(0xFF1E88E5), 6.dp.toPx(), c)
            }

            if (tiles.isEmpty()) {
                T("Caricamento mappa…", 14.sp, Secondary, modifier = Modifier.align(Alignment.Center))
            }

            Column(
                Modifier.align(Alignment.TopEnd).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ZoomButton("+") { zoom = (zoom + 1).coerceAtMost(MAX_ZOOM) }
                ZoomButton("−") { zoom = (zoom - 1).coerceAtLeast(MIN_ZOOM) }
            }

            T(
                "© OpenStreetMap, SRTM · © OpenTopoMap", 10.sp, Secondary,
                modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA0F1318))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        Column(
            Modifier.fillMaxWidth().background(CardBg).navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            val d = data
            val label = when {
                d != null && hour in d.times.indices -> mapTime(d.times[hour], hour)
                error != null -> "Dati meteo non disponibili ($error)"
                else -> "Caricamento dati…"
            }
            T(label, 15.sp, weight = FontWeight.SemiBold)
            if (d != null && d.times.size > 1) {
                Slider(
                    value = hour.toFloat(),
                    onValueChange = { hour = it.roundToInt() },
                    valueRange = 0f..(d.times.size - 1).toFloat(),
                    steps = d.times.size - 2
                )
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = showClouds, onCheckedChange = { showClouds = it })
                    T("Nuvole", 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = showRain, onCheckedChange = { showRain = it })
                    T("Precipitazioni", 14.sp)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                T("leggere", 12.sp, Secondary)
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFFFFF176), Color(0xFFFFD600), Color(0xFFFFA000),
                                Color(0xFFF4511E), Color(0xFFD50000)
                            )
                        )
                    )
                )
                Spacer(Modifier.width(8.dp))
                T("intense", 12.sp, Secondary)
            }
            T(
                "Previsione del modello meteo (griglia di circa 17 km), non radar. Zoom con due dita o con i pulsanti.",
                11.sp, Secondary, modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}
